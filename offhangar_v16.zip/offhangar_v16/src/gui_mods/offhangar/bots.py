# -*- coding: utf-8 -*-
"""Простые боты для офлайн-боя.

* При старте боя (пока идёт обратный отсчёт) сами появляются BOT_ENEMY_COUNT врагов
  (команда 2) и BOT_ALLY_COUNT союзников (команда 1, рядом с игроком).
* Враги едут к ближайшей цели (игрок или союзный бот), останавливаются на
  дистанции BOT_MIN_RANGE..BOT_MAX_RANGE, объезжают препятствия и стреляют.
* Союзники атакуют вражеских ботов, а если врагов не осталось - держатся рядом с игроком.
* Урон по своей команде не проходит (см. shooting._applyDamage).

Как это встроено в мод:
  - battle._finishVehicleSetup -> bots.onBattleStart(avatar)
  - battle._onLeaveWorld / endbattle._teardown -> bots.onBattleEnd()
  - battle.register -> bots.register() (ставит хук Vehicle.onEnterWorld)
  - Хук Vehicle.onEnterWorld добавляет бота в список машин арены ДО старта визуала:
    иначе VehicleAppearance падает с KeyError в __createStickers.
"""
import math
import random
import weakref
import cPickle

import BigWorld
import Math
import ResMgr

from constants import ARENA_UPDATE
from debug_utils import LOG_CURRENT_EXCEPTION
from gun_rotation_shared import calcPitchLimitsFromDesc
from projectile_trajectory import getShotAngles

from gui.mods.offhangar.logging import LOG_DEBUG, LOG_NOTE, LOG_ERROR
from gui.mods.offhangar import battle as off_battle
from gui.mods.offhangar import shooting as off_shooting
from gui.mods.offhangar import turret as off_turret

# ============================================================
# Config
# ============================================================
BOT_ENEMY_COUNT = 3            # врагов
BOT_ALLY_COUNT = 2             # союзников (кроме игрока)

BOT_SPAWN_DELAY = 2.0          # пауза после старта отсчёта до первого бота, сек
BOT_SPAWN_INTERVAL = 0.7       # пауза между ботами, сек
BOT_SPAWN_RING = 16.0          # союзники появляются в этом радиусе от игрока, м

BOT_AI_TICK = 0.1              # частота "мышления" бота, сек
BOT_PHYSICS_TICK = 0.04        # частота физики бота (у игрока - каждый кадр), сек
BOT_START_WAIT = 15.0          # сколько ждать старта визуала машины бота, сек
BOT_ENTITY_WAIT_STEP = 0.1
BOT_ENTITY_WAIT_TRIES = 150

BOT_MIN_RANGE = 35.0           # ближе этой дистанции враг пятится
BOT_MAX_RANGE = 70.0           # дальше этой дистанции враг едет к цели
BOT_FOLLOW_MIN = 18.0          # союзник без врагов: держится в этом кольце вокруг игрока
BOT_FOLLOW_MAX = 40.0
BOT_SHOOT_DISTANCE = 220.0
BOT_RETARGET_INTERVAL = 2.0
BOT_AIM_TOLERANCE = 0.05       # допустимая ошибка наводки, рад
BOT_INACCURACY_BASE = 0.5      # разброс точки прицеливания: база + за метр дистанции, м
BOT_INACCURACY_PER_METER = 0.012
BOT_RELOAD_FACTOR = (1.0, 1.5) # боты перезаряжаются медленнее игрока

BOT_PROBE_LENGTH_MIN = 14.0    # дальность "усов" для объезда препятствий, м
BOT_STUCK_TIME = 1.6           # столько стоим на месте при движении -> считаем, что застряли
BOT_STUCK_MIN_MOVE = 0.35      # смещение за 0.5 сек, меньше которого считаем, что не едем

# Отладочные переключатели (если игра падает - выключай по одному и смотри, что виновато)
BOT_DEBUG_NO_MOVE = False      # боты не ездят
BOT_DEBUG_NO_TURRET = False    # башни ботов не вращаются
BOT_DEBUG_NO_FIRE = False      # боты не стреляют

TEAM_ALLY = 1
TEAM_ENEMY = 2

# ============================================================
# State
# ============================================================
_REGISTERED = False
_HOOK_INSTALLED = False

_BOTS = {}              # botID -> BotAI (мёртвые тоже остаются до конца боя)
_PENDING_BOTS = []      # записи ботов, чьи Vehicle-сущности ещё создаются
_BOT_ID_COUNTER = 0
_SPAWN_TOKEN = 0        # id текущего боя; отложенные callback-и с другим id игнорируются
_SPAWNED_FOR = None     # avatar, для которого уже запланирован спавн
_PLAN = {}              # team -> [(x, z), ...] точки спавна
_REGISTERED_IDS = set() # vehicle.id, добавленные в список машин арены
_KILLED_IDS = set()     # vehicle.id, по которым отправлен VEHICLE_KILLED
_PENDING_WAIT_ACTIVE = False
_TRACER_BROKEN = [False]


# ============================================================
# Helpers
# ============================================================
def _active():
    try:
        return bool(off_battle._active())
    except Exception:
        return False


def _wrap(a):
    while a > math.pi:
        a -= 2.0 * math.pi
    while a < -math.pi:
        a += 2.0 * math.pi
    return a


def _getPlayerVehicle():
    try:
        avatar = BigWorld.player()
        vid = getattr(avatar, 'playerVehicleID', 0)
        if vid:
            return BigWorld.entity(vid)
    except Exception:
        pass
    return None


def isAlive(vehicle):
    try:
        return bool(getattr(vehicle, 'isStarted', False)) and getattr(vehicle, 'health', 0) > 0
    except Exception:
        return False


def _posOf(vehicle):
    """Положение машины. Физика мода двигает модель сама, поэтому берём позицию из неё."""
    try:
        sp = off_battle._simplePhysicsByVehID.get(vehicle.id)
        if sp is not None:
            return sp.pos
    except Exception:
        pass
    return vehicle.position


def getTeam(vehicle):
    try:
        return int(vehicle.publicInfo['team'])
    except Exception:
        return 0


def isBotVehicle(vehicle):
    try:
        return int(vehicle.publicInfo['accountDBID']) < 0
    except Exception:
        return False


def _updateArena(avatar, updateType, payload):
    try:
        avatar.updateArena(updateType, payload)
    except Exception:
        LOG_CURRENT_EXCEPTION()
        try:
            avatar.arena.update(updateType, payload)
        except Exception:
            LOG_CURRENT_EXCEPTION()


def _randomCompDescr():
    """Случайная машина из ангара игрока (артиллерию по возможности не берём)."""
    try:
        from gui.shared import g_itemsCache, REQ_CRITERIA
        vehs = list(g_itemsCache.items.getVehicles(REQ_CRITERIA.INVENTORY).values())
        pool = []
        for v in vehs:
            try:
                if getattr(v, 'type', None) == 'SPG':
                    continue
            except Exception:
                pass
            pool.append(v)
        if not pool:
            pool = vehs
        if not pool:
            return None
        veh = random.choice(pool)
        return veh.descriptor.makeCompactDescr()
    except Exception:
        LOG_CURRENT_EXCEPTION()
        return None


def _groundY(spaceID, x, z):
    try:
        res = BigWorld.wg_collideSegment(
            spaceID, Math.Vector3(x, 600.0, z), Math.Vector3(x, -100.0, z), 0)
        if res is not None and res[0] is not None:
            return float(res[0].y) + 0.3
    except Exception:
        pass
    return 0.0


# ============================================================
# Spawn points
# ============================================================
def _arenaType(avatar):
    try:
        import ArenaType
        return ArenaType.g_cache.get(avatar.arenaTypeID)
    except Exception:
        return None


def _readXmlPoints(geometryName, group, team):
    pts = []
    try:
        section = ResMgr.openSection('scripts/arena_defs/%s.xml' % geometryName)
        if section is None:
            return pts
        sub = section['gameplayTypes/ctf/%s/team%d' % (group, team)]
        if sub is None:
            return pts
        for i in range(1, 16):
            s = sub.readString('position%d' % i, '')
            if not s:
                if i > 1:
                    break
                continue
            parts = s.split()
            if len(parts) >= 2:
                pts.append((float(parts[0]), float(parts[1])))
    except Exception:
        LOG_CURRENT_EXCEPTION()
    return pts


def _enemyPoints(avatar, playerPos):
    at = _arenaType(avatar)
    if at is not None:
        geometryName = getattr(at, 'geometryName', None)
        if geometryName:
            for group in ('teamSpawnPoints', 'teamBasePositions'):
                pts = _readXmlPoints(geometryName, group, TEAM_ENEMY)
                if pts:
                    LOG_DEBUG('[BOTS] enemy spawn points from xml (%s): %s' % (group, pts))
                    return pts
        # запасной вариант: зеркальная точка относительно центра арены
        try:
            bb = getattr(at, 'boundingBox', None)
            if bb is not None:
                cx = (float(bb[0][0]) + float(bb[1][0])) * 0.5
                cz = (float(bb[0][1]) + float(bb[1][1])) * 0.5
                p = (2.0 * cx - playerPos.x, 2.0 * cz - playerPos.z)
                LOG_DEBUG('[BOTS] enemy spawn point mirrored via bounding box: %s' % (p,))
                return [p]
        except Exception:
            LOG_CURRENT_EXCEPTION()
    p = (playerPos.x + 300.0, playerPos.z)
    LOG_ERROR('[BOTS] no enemy spawn data, fallback point %s' % (p,))
    return [p]


def _makePlan(avatar):
    """Точки спавна для каждой команды (один раз на бой)."""
    pv = _getPlayerVehicle()
    if pv is None:
        return False
    playerPos = _posOf(pv)

    plan = {TEAM_ALLY: [], TEAM_ENEMY: []}

    # союзники: кольцо вокруг игрока
    n = max(1, BOT_ALLY_COUNT)
    base = random.uniform(0.0, 2.0 * math.pi)
    for i in range(BOT_ALLY_COUNT):
        ang = base + i * 2.0 * math.pi / n
        r = BOT_SPAWN_RING * (1.0 + 0.4 * (i // 6))
        plan[TEAM_ALLY].append((playerPos.x + r * math.sin(ang), playerPos.z + r * math.cos(ang)))

    # враги: точки базы/спавна команды 2 + небольшой разброс
    pts = _enemyPoints(avatar, playerPos)
    for i in range(BOT_ENEMY_COUNT):
        px, pz = pts[i % len(pts)]
        ring = 14.0 * (1 + i // len(pts)) if (i >= len(pts) or len(pts) == 1) else 0.0
        ang = random.uniform(0.0, 2.0 * math.pi)
        plan[TEAM_ENEMY].append((px + ring * math.sin(ang), pz + ring * math.cos(ang)))

    _PLAN.clear()
    _PLAN.update(plan)
    LOG_DEBUG('[BOTS] spawn plan: %s' % (plan,))
    return True


# ============================================================
# Arena registration
# ============================================================
def _makePublicInfo(compDescr, team, botID):
    info = off_battle._PublicInfo(compDescr, team)
    name = 'Bot_%d' % botID
    dbid = -botID
    info['name'] = name
    info['accountDBID'] = dbid
    try:
        info.name = name
        info.accountDBID = dbid
    except Exception:
        pass
    return info


def _arenaTuple(vid, info):
    t = list(off_battle._vehInfoTuple(vid, info['compDescr'], info['team']))
    t[2] = info['name']
    t[7] = info['accountDBID']
    return tuple(t)


def _bindPending(vehicle):
    """Сопоставляет только что появившуюся Vehicle-сущность с записью о боте.
    Порядок: уже привязана по id -> по publicInfo.accountDBID -> по близости к точке спавна."""
    for rec in _PENDING_BOTS:
        if rec.get('vid') == vehicle.id:
            return rec

    dbid = None
    try:
        dbid = int(vehicle.publicInfo['accountDBID'])
    except Exception:
        pass
    if dbid is not None and dbid < 0:
        for rec in _PENDING_BOTS:
            if rec['botID'] == -dbid and rec.get('vid') is None:
                rec['vid'] = vehicle.id
                return rec

    try:
        p = vehicle.position
        best = None
        for rec in _PENDING_BOTS:
            if rec.get('vid') is not None:
                continue
            d = math.hypot(p.x - rec['x'], p.z - rec['z'])
            if d < 6.0 and (best is None or d < best[0]):
                best = (d, rec)
        if best is not None:
            best[1]['vid'] = vehicle.id
            return best[1]
    except Exception:
        pass
    return None


def _registerArenaVehicle(vehicle, rec=None):
    """Добавляет бота в список машин арены (один раз). Безопасно вызывать повторно."""
    try:
        vid = vehicle.id
        if vid in _REGISTERED_IDS:
            return
        if rec is not None:
            info = rec['vprops']['publicInfo']
        else:
            info = vehicle.publicInfo
            if int(info['accountDBID']) >= 0:
                return
        avatar = BigWorld.player()
        if avatar is None:
            return
        _REGISTERED_IDS.add(vid)
        _updateArena(avatar, ARENA_UPDATE.VEHICLE_ADDED, cPickle.dumps(_arenaTuple(vid, info)))
        LOG_DEBUG('[BOTS] vehicle %s (%s, team %s) added to arena' % (vid, info['name'], info['team']))
    except Exception:
        LOG_CURRENT_EXCEPTION()


def preStartVisual(vehicle):
    """Вызывается из battle._safe_startVisual ДО Vehicle.startVisual: без записи в списке машин арены
    VehicleAppearance падает с KeyError в __createStickers."""
    try:
        if not _active():
            return
        avatar = BigWorld.player()
        if vehicle.id == getattr(avatar, 'playerVehicleID', 0):
            return
        rec = _bindPending(vehicle)
        if rec is None and not isBotVehicle(vehicle):
            return
        LOG_DEBUG('[BOTS] preStartVisual: entity %s matched to bot %s' % (
            vehicle.id, rec['botID'] if rec else '(by publicInfo)'))
        _registerArenaVehicle(vehicle, rec)
    except Exception:
        LOG_CURRENT_EXCEPTION()


def _patchVehicleOnEnterWorld():
    global _HOOK_INSTALLED
    if _HOOK_INSTALLED:
        return
    try:
        import Vehicle as _V
        orig = _V.Vehicle.onEnterWorld

        def onEnterWorld(self, prereqs, orig=orig):
            try:
                if _active():
                    preStartVisual(self)
            except Exception:
                LOG_CURRENT_EXCEPTION()
            return orig(self, prereqs)

        _V.Vehicle.onEnterWorld = onEnterWorld
        _HOOK_INSTALLED = True
        LOG_NOTE('[BOTS] Vehicle.onEnterWorld hook installed')
    except Exception:
        LOG_CURRENT_EXCEPTION()


def onVehicleKilled(vehicle, killerID):
    """Вызывается из shooting._applyDamage, когда здоровье машины упало до нуля."""
    try:
        vid = vehicle.id
        if vid in _KILLED_IDS:
            return
        _KILLED_IDS.add(vid)

        for ai in list(_BOTS.values()):
            if ai._vid == vid:
                ai.die()

        avatar = BigWorld.player()
        if avatar is not None:
            _updateArena(avatar, ARENA_UPDATE.VEHICLE_KILLED, cPickle.dumps((vid, killerID, 0)))
        LOG_DEBUG('[BOTS] vehicle %s destroyed by %s' % (vid, killerID))
    except Exception:
        LOG_CURRENT_EXCEPTION()


# ============================================================
# Turret
# ============================================================
class BotTurret(object):
    """Наводка башни и орудия бота.

    Башня крутится так же, как у игрока: свои матрицы (_RotAnimator) подставляются как target в
    appearance.turretMatrix / appearance.gunMatrix. Нативный filter.syncGunAngles не используется:
    при отключённой в офлайне нативной физике он валил игру сразу после старта боя."""

    TICK = 0.05

    def __init__(self):
        self._vehicle = None
        self._descr = None
        self.yaw = 0.0
        self.pitch = 0.0
        self.errYaw = 9.9
        self.errPitch = 9.9
        self._point = None
        self._pointSetAt = 0.0
        self._maxTurretSpeed = 0.5
        self._maxGunSpeed = 0.5
        self._yawLimits = None
        self._cbID = None
        self._lastTime = 0.0
        self._turretAnim = off_turret._RotAnimator()
        self._gunAnim = off_turret._RotAnimator()
        self._firstUpdateLogged = False

    def setup(self, vehicle):
        self._vehicle = weakref.proxy(vehicle)
        self._descr = vehicle.typeDescriptor
        self._maxTurretSpeed = self._descr.turret['rotationSpeed']
        self._maxGunSpeed = self._descr.gun['rotationSpeed']
        self._yawLimits = self._descr.gun['turretYawLimits']

        self._applyMatrices(0.0)
        try:
            app = vehicle.appearance
            app.turretMatrix.target = self._turretAnim.matrix
            app.gunMatrix.target = self._gunAnim.matrix
            LOG_DEBUG('[BOTS] turret matrices attached for vehicle %s' % vehicle.id)
        except Exception:
            LOG_CURRENT_EXCEPTION()

    def setTarget(self, point):
        if point is None:
            self._point = None
            self.errYaw = self.errPitch = 9.9
            return
        if self._point is None:
            self._pointSetAt = BigWorld.time()
        self._point = point

    def isAimed(self):
        if self._point is None:
            return False
        if BigWorld.time() - self._pointSetAt < 0.3:
            return False
        return abs(self.errYaw) < BOT_AIM_TOLERANCE and abs(self.errPitch) < BOT_AIM_TOLERANCE

    def start(self):
        if self._cbID is not None:
            return
        self._lastTime = BigWorld.time()
        self._cbID = BigWorld.callback(0.0, self._tick)

    def stop(self):
        if self._cbID is not None:
            try:
                BigWorld.cancelCallback(self._cbID)
            except Exception:
                pass
            self._cbID = None

    def _tick(self):
        now = BigWorld.time()
        dt = now - self._lastTime
        self._lastTime = now
        self._cbID = BigWorld.callback(self.TICK, self._tick)
        if dt <= 0.0:
            return
        dt = min(dt, 0.2)
        try:
            vehicle = self._vehicle
            if not getattr(vehicle, 'isStarted', False):
                return
            if off_battle.isPrebattle() or BOT_DEBUG_NO_TURRET:
                return
            self._update(vehicle, dt)
        except ReferenceError:
            self.stop()
        except Exception:
            LOG_CURRENT_EXCEPTION()

    def _update(self, vehicle, dt):
        point = self._point
        if point is None:
            return
        descr = self._descr

        if not self._firstUpdateLogged:
            self._firstUpdateLogged = True
            LOG_DEBUG('[BOTS] turret first update, vehicle %s' % vehicle.id)

        vehMat = Math.Matrix(vehicle.model.matrix)

        shotYaw, shotPitch = getShotAngles(descr, vehMat, (self.yaw, self.pitch), point)

        self.yaw = off_turret._stepTurretYaw(
            self.yaw, shotYaw, self._maxTurretSpeed * dt, self._yawLimits)
        limits = calcPitchLimitsFromDesc(self.yaw, descr.gun['pitchLimits'])
        self.pitch = off_turret._stepGunPitch(
            self.pitch, shotPitch, self._maxGunSpeed * dt, limits)

        self.errYaw = _wrap(shotYaw - self.yaw)
        self.errPitch = shotPitch - self.pitch

        self._applyMatrices(dt)

    def _applyMatrices(self, dt):
        turretMat = Math.Matrix()
        turretMat.setRotateY(self.yaw)
        self._turretAnim.update(turretMat, dt)

        gunMat = Math.Matrix()
        gunMat.setRotateX(self.pitch)
        self._gunAnim.update(gunMat, dt)


# ============================================================
# Bot AI
# ============================================================
class BotAI(object):
    def __init__(self, vehicle, botID, team):
        self._vehicle = weakref.proxy(vehicle)
        self._vid = vehicle.id
        self.botID = botID
        self.team = team
        self.alive = True

        self._physics = None
        self._turret = None
        self._ready = False
        self._kicked = False
        self._waited = 0.0

        self._cbID = None
        self._lastTime = 0.0

        self._targetID = None
        self._follow = False
        self._retarget = 0.0
        self._aimPoint = None
        self._aimOffset = (0.0, 0.0, 0.0)

        self._holdMode = 0
        self._holdUntil = 0.0

        self._lastPos = None
        self._lastCheck = 0.0
        self._stuckTime = 0.0
        self._moveDir = 0
        self._unstuckUntil = 0.0
        self._unstuckMove = 0
        self._unstuckTurn = 1

        self._shootCd = random.uniform(1.0, 3.0)
        self._thinkLogged = False
        self._fireDiag = False

    # --------------------------------------------------------
    def start(self):
        if self._cbID is not None:
            return
        self._lastTime = BigWorld.time()
        self._cbID = BigWorld.callback(0.0, self._tick)

    def stop(self):
        if self._cbID is not None:
            try:
                BigWorld.cancelCallback(self._cbID)
            except Exception:
                pass
            self._cbID = None
        if self._turret is not None:
            self._turret.stop()
        if self._physics is not None:
            try:
                self._physics.stop()
            except Exception:
                pass
            try:
                off_battle._simplePhysicsByVehID.pop(self._vid, None)
            except Exception:
                pass

    def die(self):
        if not self.alive:
            return
        self.alive = False
        self.stop()
        LOG_DEBUG('[BOTS] bot %s (team %s) is dead' % (self.botID, self.team))

    def vehicle(self):
        """Настоящая сущность (не weakref-proxy): нужна, чтобы `e is shooter` в поиске попаданий работало."""
        return BigWorld.entity(self._vid)

    # --------------------------------------------------------
    def _tick(self):
        self._cbID = BigWorld.callback(BOT_AI_TICK, self._tick)

        now = BigWorld.time()
        dt = now - self._lastTime
        self._lastTime = now
        if dt <= 0.0:
            return
        dt = min(dt, 0.25)

        if not _active():
            self.stop()
            return

        veh = self.vehicle()
        if veh is None:
            self.stop()
            return

        if getattr(veh, 'health', 1) <= 0:
            self.die()
            return

        if not self._ready:
            if getattr(veh, 'isStarted', False):
                self._setupControllers(veh)
            else:
                self._waited += dt
                if self._waited > 3.0 and not self._kicked:
                    # естественный запуск визуала не сработал - запускаем как для чужой машины игрока
                    self._kicked = True
                    try:
                        BigWorld.player().vehicle_onEnterWorld(veh)
                        LOG_DEBUG('[BOTS] bot %s: visual start kicked' % self.botID)
                    except Exception:
                        LOG_CURRENT_EXCEPTION()
                if self._waited > BOT_START_WAIT:
                    LOG_ERROR('[BOTS] bot %s: vehicle visual never started, giving up' % self.botID)
                    self.die()
            return

        try:
            self._think(veh, dt)
        except Exception:
            LOG_CURRENT_EXCEPTION()

    def _setupControllers(self, veh):
        phys = off_battle._simplePhysicsByVehID.get(veh.id)
        if phys is None:
            phys = off_battle.SimpleTankPhysics()
            phys.isBot = True            # не трогать матрицу/камеру игрока
            phys.tickInterval = BOT_PHYSICS_TICK
            phys.setup(veh)
            off_battle._simplePhysicsByVehID[veh.id] = phys
            phys.start()
        else:
            # физику уже запустил патч Vehicle.__startWGPhysics (для ботов - с isBot=True)
            phys.isBot = True
            phys.tickInterval = BOT_PHYSICS_TICK

        turret = BotTurret()
        turret.setup(veh)
        turret.start()

        self._physics = phys
        self._turret = turret
        self._ready = True
        self._fixVisibility(veh)
        LOG_DEBUG('[BOTS] bot %s (team %s) ready, vehicle id=%s' % (self.botID, self.team, veh.id))

    def _fixVisibility(self, veh):
        """Бот не должен быть "призраком": сбрасываем stipple (полупрозрачность появления),
        включаем targetCaps и пишем в лог состояние для диагностики."""
        try:
            veh.targetCaps = [1]
        except Exception:
            pass
        try:
            if veh.model is not None:
                veh.model.stipple = False
        except Exception:
            LOG_CURRENT_EXCEPTION()
        try:
            BigWorld.callback(2.5, lambda vid=self._vid: _clearStipple(vid))
        except Exception:
            pass
        try:
            st = off_shooting._getState(veh)
            LOG_DEBUG('[BOTS] bot %s diag: health=%s model=%s inWorld=%s pos=%s modelPos=%s ammo=%s' % (
                self.botID, getattr(veh, 'health', '?'), veh.model is not None, getattr(veh, 'inWorld', '?'),
                veh.position, veh.model.position if veh.model is not None else None, st.get('ammo')))
        except Exception:
            LOG_CURRENT_EXCEPTION()

    # --------------------------------------------------------
    # Targets
    # --------------------------------------------------------
    def _enemies(self):
        res = []
        if self.team == TEAM_ENEMY:
            pv = _getPlayerVehicle()
            if pv is not None and isAlive(pv):
                res.append(pv)
        for b in _BOTS.values():
            if b is self or b.team == self.team or not b.alive:
                continue
            v = b.vehicle()
            if v is not None and isAlive(v):
                res.append(v)
        return res

    def _currentTarget(self):
        if self._targetID is None:
            return None
        v = BigWorld.entity(self._targetID)
        if v is not None and isAlive(v):
            return v
        return None

    def _pickTarget(self, pos, dt):
        self._retarget -= dt
        cur = self._currentTarget()
        if cur is not None and self._retarget > 0.0:
            return cur
        self._retarget = BOT_RETARGET_INTERVAL

        def dist(v):
            p = _posOf(v)
            return math.hypot(p.x - pos.x, p.z - pos.z)

        self._follow = False
        cands = self._enemies()
        if cands:
            best = min(cands, key=dist)
            if cur is not None and any(c.id == cur.id for c in cands):
                if dist(cur) <= dist(best) * 1.3 + 15.0:
                    best = cur
            self._targetID = best.id
            return best

        if self.team == TEAM_ALLY:
            pv = _getPlayerVehicle()
            if pv is not None and isAlive(pv):
                self._follow = True
                self._targetID = pv.id
                return pv

        self._targetID = None
        return None

    # --------------------------------------------------------
    # Think
    # --------------------------------------------------------
    def _think(self, veh, dt):
        phys = self._physics
        turret = self._turret

        if off_battle.isPrebattle():
            phys.setFlags(0)
            return

        pos = phys.pos
        target = self._pickTarget(pos, dt)
        if target is None:
            phys.setFlags(0)
            turret.setTarget(None)
            self._aimPoint = None
            return

        tpos = _posOf(target)
        dx = tpos.x - pos.x
        dz = tpos.z - pos.z
        dist = math.hypot(dx, dz)
        desiredYaw = math.atan2(dx, dz)

        # башня
        if self._aimPoint is None:
            self._rollAimPoint(tpos, dist)
        else:
            self._aimPoint = Math.Vector3(
                tpos.x + self._aimOffset[0], tpos.y + 1.3 + self._aimOffset[1], tpos.z + self._aimOffset[2])
        turret.setTarget(self._aimPoint)

        # движение
        if self._follow:
            near, far = BOT_FOLLOW_MIN, BOT_FOLLOW_MAX
        else:
            near, far = BOT_MIN_RANGE, BOT_MAX_RANGE
        if BOT_DEBUG_NO_MOVE:
            phys.setFlags(0)
        else:
            phys.setFlags(self._steer(dt, pos, dist, desiredYaw, near, far))

        if not self._thinkLogged:
            self._thinkLogged = True
            LOG_DEBUG('[BOTS] bot %s first think: target=%s dist=%.0f follow=%s' % (
                self.botID, self._targetID, dist, self._follow))

        # стрельба
        if not self._follow and not BOT_DEBUG_NO_FIRE:
            self._shootCd -= dt
            self._diagT = getattr(self, '_diagT', 0.0) + dt
            if self._diagT > 8.0 and getattr(self, '_diagN', 0) < 3:
                self._diagT = 0.0
                self._diagN = getattr(self, '_diagN', 0) + 1
                LOG_DEBUG('[BOTS] bot %s state: dist=%.0f errYaw=%.3f errPitch=%.3f aimed=%s cd=%.1f canShoot=%s' % (
                    self.botID, dist, turret.errYaw, turret.errPitch, turret.isAimed(), self._shootCd,
                    off_shooting._canShoot(veh)))
            if self._shootCd <= 0.0 and dist <= BOT_SHOOT_DISTANCE and turret.isAimed():
                if self._fire(veh, dist):
                    self._rollAimPoint(tpos, dist)
                self._shootCd = random.uniform(0.2, 0.6)

    def _rollAimPoint(self, tpos, dist):
        r = BOT_INACCURACY_BASE + dist * BOT_INACCURACY_PER_METER
        self._aimOffset = (random.uniform(-r, r), random.uniform(-0.3, 0.3), random.uniform(-r, r))
        self._aimPoint = Math.Vector3(
            tpos.x + self._aimOffset[0], tpos.y + 1.3 + self._aimOffset[1], tpos.z + self._aimOffset[2])

    # --------------------------------------------------------
    # Movement
    # --------------------------------------------------------
    @staticmethod
    def _turnFlag(diff, deadzone=0.12):
        # в физике мода yaw растёт при флаге 8 (вправо) и падает при флаге 4 (влево)
        if diff > deadzone:
            return 8
        if diff < -deadzone:
            return 4
        return 0

    def _steer(self, dt, pos, dist, desiredYaw, near, far):
        phys = self._physics
        yaw = phys.yaw
        now = BigWorld.time()

        # режим "выбираемся из тупика"
        if now < self._unstuckUntil:
            flags = 2 if self._unstuckMove > 0 else 1
            flags |= 8 if self._unstuckTurn > 0 else 4
            self._moveDir = 0
            return flags

        # выбор режима
        if dist > far:
            mode = 1
        elif dist < near:
            mode = -1
        else:
            if now > self._holdUntil:
                self._holdMode = random.choice((0, 0, 0, 1, -1))
                self._holdUntil = now + random.uniform(1.5, 4.0)
            mode = self._holdMode

        flags = 0
        if mode == 1:
            steerYaw = self._avoid(pos, desiredYaw)
            diff = _wrap(steerYaw - yaw)
            if abs(diff) < 1.1:
                flags |= 1
            flags |= self._turnFlag(diff)
        elif mode == -1:
            diff = _wrap(desiredYaw - yaw)            # корпус смотрит на цель, едем задним ходом
            flags |= self._turnFlag(diff)
            if self._clearDist(pos, yaw + math.pi, 8.0) > 6.0:
                flags |= 2
        else:
            diff = _wrap(desiredYaw - yaw)
            if abs(diff) > 0.35:
                flags |= self._turnFlag(diff)

        # детектор застревания
        moving = 1 if (flags & 1) else (-1 if (flags & 2) else 0)
        self._moveDir = moving
        if moving != 0 and now - self._lastCheck >= 0.5:
            if self._lastPos is not None:
                moved = math.hypot(pos.x - self._lastPos[0], pos.z - self._lastPos[1])
                if moved < BOT_STUCK_MIN_MOVE:
                    self._stuckTime += now - self._lastCheck
                else:
                    self._stuckTime = 0.0
            self._lastPos = (pos.x, pos.z)
            self._lastCheck = now
            if self._stuckTime >= BOT_STUCK_TIME:
                self._stuckTime = 0.0
                self._unstuckUntil = now + random.uniform(1.5, 2.5)
                self._unstuckMove = -moving
                self._unstuckTurn = random.choice((-1, 1))
                LOG_DEBUG('[BOTS] bot %s stuck -> unstuck maneuver' % self.botID)
        elif moving == 0:
            self._stuckTime = 0.0
            self._lastPos = (pos.x, pos.z)
            self._lastCheck = now

        return flags

    def _avoid(self, pos, desiredYaw):
        """Ищет направление, ближайшее к желаемому, в котором впереди свободно."""
        phys = self._physics
        spd = abs(getattr(phys, '_curSpeed', 0.0))
        length = max(BOT_PROBE_LENGTH_MIN, phys.params.halfLength * 2.5 + spd * 1.5)

        best = None
        for ang in (0.0, 0.5, -0.5, 1.0, -1.0, 1.5, -1.5):
            d = self._clearDist(pos, desiredYaw + ang, length)
            if d >= length * 0.95:
                return desiredYaw + ang
            score = d - abs(ang) * 2.0
            if best is None or score > best[0]:
                best = (score, ang)
        return desiredYaw + best[1]

    def _clearDist(self, pos, yaw, length):
        """Свободная дистанция до статического препятствия вдоль курса yaw (три параллельных луча по ширине корпуса)."""
        try:
            spaceID = self._vehicle.spaceID
        except Exception:
            return length

        phys = self._physics
        p = phys.params
        dirX = math.sin(yaw)
        dirZ = math.cos(yaw)
        rightX = dirZ
        rightZ = -dirX

        lift = max(getattr(off_battle, 'STP_COLLIDE_BASE_LIFT_MIN', 0.25),
                   getattr(p, 'clearance', 0.5) * 0.65)
        baseY = phys.pos.y + lift
        heights = getattr(off_battle, 'STP_COLLIDE_HEIGHTS', (0.05, 0.35, 0.75))
        probeHeights = (heights[len(heights) // 2], heights[-1])
        ignoreN = getattr(off_battle, 'STP_COLLIDE_GROUND_NORMAL_IGNORE', 0.45)
        half = p.halfLength
        total = length + half

        best = length
        for lat in (0.0, p.halfWidth * 0.9, -p.halfWidth * 0.9):
            bx = pos.x + rightX * lat
            bz = pos.z + rightZ * lat
            for h in probeHeights:
                start = Math.Vector3(bx, baseY + h, bz)
                end = Math.Vector3(bx + dirX * total, baseY + h, bz + dirZ * total)
                try:
                    res = BigWorld.wg_collideSegment(spaceID, start, end, 0)
                except Exception:
                    res = None
                if res is None or res[0] is None:
                    continue
                try:
                    if len(res) > 1 and abs(float(res[1][1])) > ignoreN:
                        continue          # пологий склон/земля - не препятствие
                except Exception:
                    pass
                hp = res[0]
                t = (hp.x - start.x) * dirX + (hp.z - start.z) * dirZ - half
                if t < best:
                    best = max(0.0, t)
        return best

    # --------------------------------------------------------
    # Shooting
    # --------------------------------------------------------
    def _fire(self, vehicle, dist):
        """Выстрел бота. Возвращает True, если выстрел произошёл."""
        if vehicle is None or not off_shooting._canShoot(vehicle):
            return False

        origin, direction = off_shooting._shotOrigin(vehicle)
        gunDescr = vehicle.typeDescriptor.gun
        shot = gunDescr['shots'][vehicle.typeDescriptor.activeGunShotIndex]
        shellDescr = shot['shell']
        maxDistance = shot['maxDistance']
        end = origin + direction * maxDistance

        hit = off_shooting._findHitVehicle(vehicle, origin, end)
        staticHit = off_shooting._findStaticHit(vehicle, origin, end)

        hitTarget = None
        hitDist = maxDistance
        endPoint = end
        kind = 'none'
        normal = None

        if hit is not None and (staticHit is None or hit[1].dist <= staticHit[0]):
            hitTarget = hit
            hitDist = hit[1].dist
            endPoint = origin + direction * hitDist
            kind = 'vehicle'
        elif staticHit is not None:
            hitDist, endPoint, normal = staticHit
            kind = 'static'

        # стреляем только по вражеским машинам, в стены/союзников не тратим снаряды
        if kind != 'vehicle':
            if not self._fireDiag:
                self._fireDiag = True
                LOG_DEBUG('[BOTS] bot %s aimed but ray hits %s (hit=%s static=%s)' % (
                    self.botID, kind, hit is not None, staticHit is not None))
            return False
        if getTeam(hitTarget[0]) == self.team or not isAlive(hitTarget[0]):
            return False

        avatar = BigWorld.player()

        # боезапас и перезарядка
        st = off_shooting._getState(vehicle)
        shellCD = off_shooting._currentShellCD(vehicle)
        st['ammo'][shellCD] = max(0, st['ammo'].get(shellCD, 0) - 1)
        if st['ammo'][shellCD] <= 0:
            st['ammo'][shellCD] = 10          # у ботов снаряды не кончаются
        st['reloadEnd'] = BigWorld.time() + gunDescr['reloadTime'] * random.uniform(*BOT_RELOAD_FACTOR)

        target, res = hitTarget
        off_shooting._applyDamage(vehicle.id, target, shellDescr, res.hitAngleCos, res.armor, res.dist, maxDistance)
        try:
            target.showDamageFromShot(vehicle.id, [], shellDescr['effectsIndex'])
        except Exception:
            LOG_CURRENT_EXCEPTION()

        # дульная вспышка / отдача
        try:
            vehicle.showShooting(gunDescr['burst'][0], True)
        except Exception:
            LOG_CURRENT_EXCEPTION()

        # трассер (если клиент его не принял - один раз пишем в лог и больше не пытаемся)
        if not _TRACER_BROKEN[0]:
            try:
                shotID = off_shooting._nextShotID()
                velocity = direction * shot['speed']
                avatar.showTracer(vehicle.id, shotID, shellDescr['effectsIndex'],
                                  origin, velocity, shot['gravity'], maxDistance)
                flight = max(0.01, hitDist / max(1.0, shot['speed']))
                BigWorld.callback(flight, lambda sid=shotID, ep=endPoint: _stopTracer(sid, ep))
            except Exception:
                _TRACER_BROKEN[0] = True
                LOG_ERROR('[BOTS] showTracer failed, bot tracers disabled')
                LOG_CURRENT_EXCEPTION()
        return True


def _clearStipple(vid):
    try:
        e = BigWorld.entity(vid)
        if e is not None and getattr(e, 'model', None) is not None and e.model.stipple:
            e.model.stipple = False
            LOG_DEBUG('[BOTS] stipple cleared for vehicle %s' % vid)
    except Exception:
        pass


def _stopTracer(shotID, endPoint):
    try:
        av = BigWorld.player()
        if av is not None:
            av.stopTracer(shotID, endPoint)
    except Exception:
        pass


# ============================================================
# Spawn
# ============================================================
def _completeBotSpawn(avatar, vehicle, rec):
    botID = rec['botID']
    try:
        for k, v in rec['vprops'].items():
            try:
                setattr(vehicle, k, v)
            except Exception:
                pass

        _registerArenaVehicle(vehicle, rec)     # на случай, если до старта визуала не успели (идемпотентно)

        ai = BotAI(vehicle, botID, rec['team'])
        _BOTS[botID] = ai
        ai.start()
        LOG_DEBUG('[BOTS] bot %s created: team=%s entityID=%s' % (botID, rec['team'], vehicle.id))
    except Exception:
        LOG_CURRENT_EXCEPTION()


def _findEntityFor(rec, ownID, known):
    import Vehicle as _V
    vid = rec.get('vid')
    if vid is not None:
        e = BigWorld.entity(vid)
        if e is not None:
            return e
    for e in list(BigWorld.entities.values()):
        if not isinstance(e, _V.Vehicle) or e.id == ownID or e.id in known:
            continue
        try:
            if int(e.publicInfo['accountDBID']) == -rec['botID']:
                rec['vid'] = e.id
                return e
        except Exception:
            pass
        try:
            p = e.position
            if math.hypot(p.x - rec['x'], p.z - rec['z']) < 6.0:
                rec['vid'] = e.id
                return e
        except Exception:
            pass
    return None


def _dumpVehicles(ownID):
    try:
        import Vehicle as _V
        for e in list(BigWorld.entities.values()):
            if isinstance(e, _V.Vehicle):
                try:
                    dbid = e.publicInfo['accountDBID']
                except Exception:
                    dbid = '?'
                LOG_DEBUG('[BOTS]   Vehicle entity id=%s own=%s inWorld=%s pos=%s dbid=%s started=%s' % (
                    e.id, e.id == ownID, getattr(e, 'inWorld', '?'), e.position, dbid,
                    getattr(e, 'isStarted', '?')))
    except Exception:
        LOG_CURRENT_EXCEPTION()


def _waitForBotEntity(token, triesLeft):
    global _PENDING_WAIT_ACTIVE

    if token != _SPAWN_TOKEN or not _active():
        _PENDING_WAIT_ACTIVE = False
        del _PENDING_BOTS[:]
        return

    try:
        avatar = BigWorld.player()
        ownID = getattr(avatar, 'playerVehicleID', 0)
        known = set(ai._vid for ai in _BOTS.values())

        for rec in list(_PENDING_BOTS):
            e = _findEntityFor(rec, ownID, known)
            if e is None or not getattr(e, 'inWorld', True):
                continue
            _PENDING_BOTS.remove(rec)
            known.add(e.id)
            _completeBotSpawn(avatar, e, rec)
    except Exception:
        LOG_CURRENT_EXCEPTION()

    if _PENDING_BOTS:
        if triesLeft > 0:
            BigWorld.callback(BOT_ENTITY_WAIT_STEP, lambda: _waitForBotEntity(token, triesLeft - 1))
        else:
            _PENDING_WAIT_ACTIVE = False
            LOG_ERROR('[BOTS] wait timeout, %s bot(s) still pending: %s' % (
                len(_PENDING_BOTS), [(r['botID'], r['team'], r.get('vid')) for r in _PENDING_BOTS]))
            _dumpVehicles(getattr(BigWorld.player(), 'playerVehicleID', 0))
            del _PENDING_BOTS[:]
    else:
        _PENDING_WAIT_ACTIVE = False


def _spawnOne(token, team, idx):
    global _BOT_ID_COUNTER, _PENDING_WAIT_ACTIVE

    if token != _SPAWN_TOKEN or not _active():
        return

    avatar = BigWorld.player()
    points = _PLAN.get(team) or []
    if avatar is None or idx >= len(points):
        return

    compDescr = _randomCompDescr()
    if compDescr is None:
        LOG_ERROR('[BOTS] spawn skipped: no vehicle for bot')
        return

    _BOT_ID_COUNTER += 1
    botID = _BOT_ID_COUNTER

    x, z = points[idx]
    y = _groundY(avatar.spaceID, x, z)

    # смотрит в сторону центра боя: враги - на игрока, союзники - от игрока
    pv = _getPlayerVehicle()
    yaw = 0.0
    try:
        pp = _posOf(pv)
        yaw = math.atan2(pp.x - x, pp.z - z)
        if team == TEAM_ALLY:
            yaw = math.atan2(x - pp.x, z - pp.z)
    except Exception:
        pass

    vprops = {
        'publicInfo': _makePublicInfo(compDescr, team, botID),
        'health': off_battle._getMaxHealth(compDescr),
        'isCrewActive': True,
        'engineMode': (0, 0),
        'publicStateModifiers': [],
        'damageStickers': [],
        'gunAnglesPacked': 0,
        'isStrafing': False,
    }
    rec = {'botID': botID, 'team': team, 'compDescr': compDescr, 'vprops': vprops,
           'x': x, 'z': z, 'vid': None}

    # запись нужна ДО createEntity: визуал может стартовать прямо внутри этого вызова
    _PENDING_BOTS.append(rec)

    LOG_DEBUG('[BOTS] spawning bot %s team=%s at (%.1f, %.1f, %.1f)' % (botID, team, x, y, z))

    try:
        result = BigWorld.createEntity('Vehicle', avatar.spaceID, 0, (x, y, z), (0.0, 0.0, yaw), vprops)
        LOG_DEBUG('[BOTS] createEntity -> %r' % (result,))
        if result is not None and rec.get('vid') is None:
            try:
                rec['vid'] = result if isinstance(result, (int, long)) else result.id
            except Exception:
                pass
    except Exception:
        LOG_CURRENT_EXCEPTION()
        try:
            _PENDING_BOTS.remove(rec)
        except ValueError:
            pass
        return

    if not _PENDING_WAIT_ACTIVE:
        _PENDING_WAIT_ACTIVE = True
        BigWorld.callback(BOT_ENTITY_WAIT_STEP, lambda: _waitForBotEntity(token, BOT_ENTITY_WAIT_TRIES))


def _beginSpawning(token):
    if token != _SPAWN_TOKEN or not _active():
        return
    avatar = BigWorld.player()
    if avatar is None or not _makePlan(avatar):
        LOG_ERROR('[BOTS] cannot make spawn plan (player vehicle not ready)')
        return

    queue = []
    for i in range(max(BOT_ENEMY_COUNT, BOT_ALLY_COUNT)):
        if i < BOT_ENEMY_COUNT:
            queue.append((TEAM_ENEMY, i))
        if i < BOT_ALLY_COUNT:
            queue.append((TEAM_ALLY, i))

    for k, (team, idx) in enumerate(queue):
        BigWorld.callback(k * BOT_SPAWN_INTERVAL,
                          lambda t=team, i=idx: _spawnOne(token, t, i))


# ============================================================
# Battle hooks (вызываются из battle.py / endbattle.py)
# ============================================================
def onBattleStart(avatar):
    global _SPAWN_TOKEN, _SPAWNED_FOR

    if _SPAWNED_FOR is avatar:
        return
    onBattleEnd()                       # на всякий случай чистим остатки прошлого боя
    _SPAWNED_FOR = avatar
    token = _SPAWN_TOKEN
    LOG_NOTE('[BOTS] battle started: %s enemies + %s allies in %.1fs' % (
        BOT_ENEMY_COUNT, BOT_ALLY_COUNT, BOT_SPAWN_DELAY))
    BigWorld.callback(BOT_SPAWN_DELAY, lambda: _beginSpawning(token))


def onBattleEnd():
    global _SPAWN_TOKEN, _SPAWNED_FOR, _PENDING_WAIT_ACTIVE

    _SPAWN_TOKEN += 1
    _SPAWNED_FOR = None
    _PENDING_WAIT_ACTIVE = False

    for ai in list(_BOTS.values()):
        try:
            ai.stop()
        except Exception:
            LOG_CURRENT_EXCEPTION()
    _BOTS.clear()
    del _PENDING_BOTS[:]
    _PLAN.clear()
    _REGISTERED_IDS.clear()
    _KILLED_IDS.clear()


# ============================================================
# Registration
# ============================================================
def register():
    global _REGISTERED
    if _REGISTERED:
        return
    _REGISTERED = True
    _patchVehicleOnEnterWorld()
    LOG_NOTE('[BOTS] registered (enemies=%s, allies=%s)' % (BOT_ENEMY_COUNT, BOT_ALLY_COUNT))


def fini():
    global _REGISTERED
    _REGISTERED = False
    onBattleEnd()
