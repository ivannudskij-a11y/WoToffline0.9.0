# -- coding: utf-8 --
import random
import cPickle
import re
import weakref
import math
import Math
import BigWorld
import AccountCommands
import ArenaType
import ResMgr
import AreaDestructibles
import SoundGroups
import DestructiblesCache
import AvatarInputHandler
from constants import (
    DESTRUCTIBLE_MATKIND,
    QUEUE_TYPE,
    ARENA_UPDATE,
    ARENA_GUI_TYPE,
    ARENA_BONUS_TYPE,
)
from items import ITEM_TYPE_INDICES
from debug_utils import LOG_CURRENT_EXCEPTION

from gui.mods.offhangar.logging import LOG_DEBUG, LOG_NOTE, LOG_ERROR
from gui.mods.offhangar.server import BASE_REQUESTS, FakeServer
from gui.mods.offhangar._constants import OFFLINE_NICKNAME, OFFLINE_DBID


# ============================================================
# Offline battle state
# ============================================================
_REGISTERED = False
_BATTLE_ACTIVE = False

_ORIG_INIT_STEP = None
_ORIG_ON_ENTER_WORLD = None
_ORIG_ON_LEAVE_WORLD = None

_PENDING_CTX = None

_AVATAR_FAKE_SERVER = FakeServer('OfflineAvatarServer', True)

_OFFLINE_ATTR_DEFAULTS = {
    'isGunLocked': False,
}

_simplePhysicsByVehID = {}
_simpleTurretByVehID = {}


def _ensureSoundGroupsInstance():
    try:
        sg = getattr(SoundGroups, 'g_instance', None)
        if sg is None:
            sg = SoundGroups.SoundGroups()
            SoundGroups.g_instance = sg
        return sg
    except Exception:
        LOG_CURRENT_EXCEPTION()
        return None


def _startVehicleEngineSound(vehicle):
    try:
        ap = getattr(vehicle, 'appearance', None)
        if ap is None:
            return None

        sound = getattr(vehicle, '_offhangar_engineSound', None)
        if sound is None:
            sound = getattr(ap, '_VehicleAppearance__engineSound', None)
        if sound is not None:
            return sound

        sg = _ensureSoundGroupsInstance()
        if sg is None:
            return None

        td = getattr(vehicle, 'typeDescriptor', None)
        if td is None:
            return None

        if getattr(vehicle, 'isPlayer', False):
            event = td.engine.get('soundPC') or td.engine.get('sound')
        else:
            event = td.engine.get('soundNPC') or td.engine.get('sound')

        model = None
        try:
            player = BigWorld.player()
            model = player.newFakeModel()
        except Exception:
            model = None

        if model is None:
            try:
                hull = ap.modelsDesc.get('hull', {}).get('model')
            except Exception:
                hull = None
            model = hull

        if model is None:
            return None

        try:
            sound = sg.getSound(model, event)
        except Exception:
            try:
                sound = sg.FMODgetSound(event)
            except Exception:
                sound = None

        if sound is None:
            return None

        try:
            sound.play()
        except Exception:
            pass

        try:
            vehicle._offhangar_engineSound = sound
        except Exception:
            pass

        try:
            setattr(ap, '_VehicleAppearance__engineSound', sound)
        except Exception:
            pass

        return sound
    except Exception:
        LOG_CURRENT_EXCEPTION()
        return None


def _updateVehicleEngineSound(vehicle):
    try:
        sound = getattr(vehicle, '_offhangar_engineSound', None)
        if sound is None:
            sound = getattr(getattr(vehicle, 'appearance', None), '_VehicleAppearance__engineSound', None)
        if sound is None:
            return

        try:
            speed = float(vehicle.getSpeed())
        except Exception:
            speed = 0.0

        try:
            phys = vehicle.typeDescriptor.physics
            speedMax = float(phys.get('speedLimits', (15.0, 5.0))[0])
            speedBack = float(phys.get('speedLimits', (15.0, 5.0))[1])
            speedRange = speedMax + speedBack
        except Exception:
            speedMax = 15.0
            speedBack = 5.0
            speedRange = 20.0

        if speedRange > 0.0:
            speedRangeGear = speedRange / 3.0
            gearNum = int(math.ceil(math.floor(abs(speed) * 50.0) / 50.0 / speedRangeGear)) if speedRangeGear > 0.0 else 0
            rpm = abs(1.0 + (speed - gearNum * speedRangeGear) / speedRangeGear) if gearNum != 0 else 0.0
        else:
            gearNum = 0
            rpm = 0.0

        rpm = max(0.0, min(1.0, rpm))

        try:
            param = sound.param('RPM')
            if param is not None:
                param.value = rpm
        except Exception:
            pass

        try:
            engineMode = getattr(vehicle, 'engineMode', (0, 0))
            engineLoad = engineMode[0]
            if engineLoad == 3:
                engineLoad = 2
            elif engineLoad == 2:
                engineLoad = 3
            param = sound.param('engine_load')
            if param is not None:
                param.value = engineLoad
        except Exception:
            pass
    except Exception:
        LOG_CURRENT_EXCEPTION()


# ============================================================
# Simple physics constants
# ============================================================
STP_GROUND_RAY_UP = 3.0
STP_GROUND_RAY_DOWN = 10.0
STP_GROUND_RAY_WIDE_UP = 500.0
STP_GROUND_RAY_WIDE_DOWN = 500.0

STP_GROUND_RESOLVE_MAX_TRIES = 50
STP_GROUND_RESOLVE_DELAY = 0.1

STP_COLLIDE_MARGIN = 0.15
STP_COLLIDE_HEIGHTS = (0.05, 0.35, 0.75)
STP_COLLIDE_BASE_LIFT_MIN = 0.25
STP_COLLIDE_GROUND_NORMAL_IGNORE = 0.45

STP_GROUND_FOLLOW_RATE = 18.0
STP_USE_SMOOTH_GROUND = True

STP_PITCH_RESPONSE = 12.0
STP_ROLL_RESPONSE = 14.0
STP_MAX_PITCH = 0.6
STP_MAX_ROLL = 0.45

STP_INVERT_VISUAL_PITCH = True
STP_INVERT_VISUAL_ROLL = True


# ============================================================
# Basic helpers
# ============================================================
def _active():
    return _BATTLE_ACTIVE


def _clampValue(minValue, maxValue, value):
    if value < minValue:
        return minValue
    if value > maxValue:
        return maxValue
    return value


def _isOffline():
    try:
        p = BigWorld.player()
    except Exception:
        return False

    return bool(getattr(p, 'isOffline', False)) or hasattr(p, 'fakeServer')


# ============================================================
# Destructibles helpers
# ============================================================
_DESTR_DESC_PATCHED = False


def _patchDestructibleDescLookup():
    global _DESTR_DESC_PATCHED

    if _DESTR_DESC_PATCHED:
        return

    _DESTR_DESC_PATCHED = True

    try:
        origGetDescByFilename = DestructiblesCache.DestructiblesCache.getDescByFilename

        def _patchedGetDescByFilename(self, filename):
            if not filename:
                return origGetDescByFilename(self, filename)

            try:
                f = filename.strip()
            except Exception:
                f = filename

            f = f.replace('\\', '/')
            f = re.sub('/lod./', '/lod0/', f)

            desc = origGetDescByFilename(self, f)
            if desc is not None:
                return desc

            low = f.lower()

            desc = origGetDescByFilename(self, low)
            if desc is not None:
                return desc

            if low.startswith('content/'):
                desc = origGetDescByFilename(self, f[8:])
                if desc is None:
                    desc = origGetDescByFilename(self, low[8:])
                if desc is not None:
                    return desc
            else:
                desc = origGetDescByFilename(self, 'content/' + f)
                if desc is None:
                    desc = origGetDescByFilename(self, 'content/' + low)
                if desc is not None:
                    return desc

            if not hasattr(self, '_offhangar_descAltMap'):
                alt = {}

                for d in getattr(self, '_DestructiblesCache__descs', []):
                    fn = d.get('filename', '')

                    try:
                        fn = fn.strip()
                    except Exception:
                        pass

                    fn = fn.replace('\\', '/').lower()
                    if not fn:
                        continue

                    alt[fn] = d

                    base = fn.rsplit('/', 1)[-1]
                    alt[base] = d

                    noext = base.rsplit('.', 1)[0]
                    alt[noext] = d

                self._offhangar_descAltMap = alt

            base = f.rsplit('/', 1)[-1].lower()
            noext = base.rsplit('.', 1)[0]

            return self._offhangar_descAltMap.get(base) or self._offhangar_descAltMap.get(noext)

        DestructiblesCache.DestructiblesCache.getDescByFilename = _patchedGetDescByFilename
        LOG_DEBUG('DestructiblesCache desc lookup patch installed')

    except Exception:
        LOG_CURRENT_EXCEPTION()


def _ensureDestructibleChunkLoaded(mgr, spaceID, chunkID):
    if mgr is None:
        return False

    if mgr.isChunkLoaded(chunkID):
        return True

    try:
        filenames = BigWorld.wg_getChunkDestrFilenames(spaceID, chunkID)
    except Exception:
        LOG_CURRENT_EXCEPTION()
        return False

    if filenames is None:
        return False

    try:
        count = len(filenames)
    except Exception:
        try:
            count = int(filenames)
        except Exception:
            return False

    if count <= 0:
        try:
            mgr._DestructiblesManager__loadedChunkIDs[chunkID] = count
        except Exception:
            LOG_CURRENT_EXCEPTION()

        return mgr.isChunkLoaded(chunkID)

    try:
        mgr.onChunkLoad(chunkID, count)
    except Exception:
        LOG_CURRENT_EXCEPTION()

    if mgr.isChunkLoaded(chunkID):
        return True

    try:
        for idx in xrange(count):
            mgr._DestructiblesManager__setDestructibleInitialState(chunkID, idx)

        mgr._DestructiblesManager__loadedChunkIDs[chunkID] = count
    except Exception:
        LOG_CURRENT_EXCEPTION()

    return mgr.isChunkLoaded(chunkID)

# ============================================================
# Turret rotation helper
# ============================================================
def _startTurretRotation(avatar, vehicle):
    try:
        from gui.mods.offhangar import turret as off_turret

        ctrl = off_turret.SimpleTurretRotation()
        ctrl.setup(vehicle, avatar)

        _simpleTurretByVehID[vehicle.id] = ctrl
        ctrl.start()
    except Exception:
        LOG_CURRENT_EXCEPTION()


# ============================================================
# Vehicle params
# ============================================================
class _VehicleParams(object):
    def __init__(self, vehicle):
        self.maxFwd = 15.0
        self.maxBack = 5.0
        self.accel = 6.0
        self.brake = 10.0
        self.rotRate = 1.2
        self.rotAccel = 4.0
        self.rotDecel = 6.0
        self.massTonnes = 50.0
        self.terrainResistance = 1.0
        self.terrainDrag = 0.03
        self.rotLimit = 1.0

        self.halfLength = 3.0
        self.halfWidth = 1.5
        self.clearance = 0.5

        try:
            td = vehicle.typeDescriptor

            phys = getattr(td, 'physics', None)
            if phys is not None:
                speedLimits = phys.get('speedLimits', (15.0, 5.0))

                self.maxFwd = float(speedLimits[0])
                self.maxBack = float(speedLimits[1])

                self.maxFwd = _clampValue(4.0, 20.0, self.maxFwd)
                self.maxBack = _clampValue(2.0, 10.0, self.maxBack)

                weight = float(phys.get('weight', 50000.0))
                enginePower = float(phys.get('enginePower', 350000.0))

                self.massTonnes = max(1.0, weight * 0.001)

                powerToWeight = enginePower / max(1.0, weight)
                self.accel = _clampValue(3.0, 14.0, 3.0 + powerToWeight * 1.2)
                self.brake = _clampValue(6.0, 18.0, self.accel * 1.4)

                self.rotLimit = float(phys.get('rotationSpeedLimit', 1.2) or 1.2)
                self.rotRate = _clampValue(0.45, 2.2, self.rotLimit)

                terr = phys.get('terrainResistance', (1.0, 1.2, 1.5))
                self.terrainResistance = float(terr[0])
                self.terrainDrag = _clampValue(0.0, 0.2, 0.03 * self.terrainResistance)

            chassis = getattr(td, 'chassis', None)
            if chassis is not None:
                hitTester = chassis.get('hitTester', None)
                if hitTester is not None:
                    bbox = getattr(hitTester, 'bbox', None)
                    if bbox is not None:
                        chassisMin = bbox[0]
                        chassisMax = bbox[1]

                        self.halfWidth = max(0.8, (chassisMax[0] - chassisMin[0]) * 0.5)
                        self.halfLength = max(1.5, (chassisMax[2] - chassisMin[2]) * 0.5)

                hullPosition = chassis.get('hullPosition', None)
                if hullPosition is not None and hitTester is not None:
                    bbox = getattr(hitTester, 'bbox', None)
                    if bbox is not None:
                        chassisMin = bbox[0]
                        self.clearance = max(0.2, float(hullPosition.y) + float(chassisMin.y))

        except Exception:
            LOG_CURRENT_EXCEPTION()

        LOG_DEBUG(
            'vehicle params: maxFwd=%.2f maxBack=%.2f accel=%.2f brake=%.2f rot=%.2f '
            'mass=%.2f terr=%.2f halfLen=%.2f halfWidth=%.2f clearance=%.2f' % (
                self.maxFwd,
                self.maxBack,
                self.accel,
                self.brake,
                self.rotRate,
                self.massTonnes,
                self.terrainResistance,
                self.halfLength,
                self.halfWidth,
                self.clearance,
            )
        )


# ============================================================
# SimpleTankPhysics
# ============================================================
# ------------------------------------------------------------
# Анимация гусениц / колёс
# ------------------------------------------------------------
# Клиентский WGVehicleFashion крутит гусеницы по fashion.movementInfo (Vector4: [1] и [2] - движение левой и
# правой гусеницы), а пыль/звук берут скорость из filter.speedInfo ([0] - скорость, [1] - скорость поворота).
# Нативный фильтр в офлайн-бою эти значения не обновляет, поэтому физика мода пишет их сама.
#
# Единицы movementInfo в движке не документированы, поэтому режимы переключаются прямо в бою (пишутся в лог):
#   F6 - единицы: абсолютные м/с  <->  относительные (-1..1)
#   F7 - направление вращения гусениц (вперёд/назад)
#   F8 - направление вращения при повороте на месте (левая/правая)
TRACK_UNITS_ABS = True
TRACK_INVERT_SCROLL = False
TRACK_INVERT_TURN = False
_TRACK_MAX_INIT_TRIES = 400
_TRACK_ATTACH_INTERVAL = 0.3
_TRACK_MAX_ATTACH_TRIES = 40
_TRACK_KEYS_HOOKED = False


def _logTrackMode(why):
    LOG_DEBUG('tracks: MODE (%s) units=%s invertScroll=%s invertTurn=%s' % (
        why, 'abs m/s' if TRACK_UNITS_ABS else 'relative -1..1', TRACK_INVERT_SCROLL, TRACK_INVERT_TURN))


def _patchTrackKeys():
    """F6/F7/F8 - переключение режимов анимации гусениц прямо в бою (для подбора единиц и направления)."""
    global _TRACK_KEYS_HOOKED
    if _TRACK_KEYS_HOOKED:
        return
    try:
        import Avatar as _A
        import Keys as _K
        cls = _A.PlayerAvatar
        origHandleKey = cls.handleKey
        kUnits = getattr(_K, 'KEY_F6', None)
        kScroll = getattr(_K, 'KEY_F7', None)
        kTurn = getattr(_K, 'KEY_F8', None)

        def handleKey(self, isDown, key, mods, orig=origHandleKey):
            global TRACK_UNITS_ABS, TRACK_INVERT_SCROLL, TRACK_INVERT_TURN
            try:
                if isDown and _BATTLE_ACTIVE and key in (kUnits, kScroll, kTurn):
                    if key == kUnits:
                        TRACK_UNITS_ABS = not TRACK_UNITS_ABS
                    elif key == kScroll:
                        TRACK_INVERT_SCROLL = not TRACK_INVERT_SCROLL
                    else:
                        TRACK_INVERT_TURN = not TRACK_INVERT_TURN
                    _logTrackMode('hotkey')
                    return True
            except Exception:
                LOG_CURRENT_EXCEPTION()
            return orig(self, isDown, key, mods)

        cls.handleKey = handleKey
        _TRACK_KEYS_HOOKED = True
        LOG_DEBUG('tracks: hotkeys F6/F7/F8 installed')
        _logTrackMode('initial')
    except Exception:
        LOG_CURRENT_EXCEPTION()


def _newVec4Provider():
    """Записываемый Vector4-провайдер: пробуем известные в BigWorld классы."""
    for name in ('Vector4Basic', 'Vector4Provider'):
        cls = getattr(Math, name, None)
        if cls is None:
            continue
        try:
            p = cls()
            p.value = Math.Vector4(0.0, 0.0, 0.0, 0.0)
            if p.value is not None:
                return p
        except Exception:
            pass
    LOG_ERROR('tracks: no writable Vector4 provider class; Math has: %s' % (
        [n for n in dir(Math) if 'Vector4' in n],))
    return None


def _canWriteProv(prov):
    try:
        prov.value = Math.Vector4(0.0, 0.0, 0.0, 0.0)
        v = prov.value
        return v is not None and len(v) >= 3
    except Exception:
        return False


def _initTrackAnimation(vehicle):
    """Находим fashion и провайдеры. Возвращает dict или None, если appearance ещё не готов."""
    app = getattr(vehicle, 'appearance', None)
    if app is None:
        return None
    fashion = getattr(app, 'fashion', None)
    if fashion is None:
        fashion = getattr(app, '_VehicleAppearance__fashion', None)
    if fashion is None:
        return None

    st = {'app': app, 'fashion': fashion, 'movement': None, 'speed': None,
          'attached': False, 'tries': 0, 'next': 0.0}

    try:
        mi = fashion.movementInfo
    except Exception:
        mi = None
    LOG_DEBUG('tracks: fashion=%s movementInfo=%s' % (type(fashion).__name__, type(mi).__name__))

    if mi is not None and _canWriteProv(mi):
        st['movement'] = mi
        LOG_DEBUG('tracks: using native fashion.movementInfo provider (writable)')
    else:
        own = _newVec4Provider()
        if own is not None:
            try:
                fashion.movementInfo = own
                st['movement'] = own
                LOG_DEBUG('tracks: fashion.movementInfo replaced by %s' % type(own).__name__)
            except Exception:
                LOG_CURRENT_EXCEPTION()

    try:
        si = vehicle.filter.speedInfo
        if si is not None and _canWriteProv(si):
            st['speed'] = si
    except Exception:
        pass
    LOG_DEBUG('tracks: speedInfo writable=%s' % (st['speed'] is not None))
    return st


def _attachTrackFashion(vehicle, st):
    """Штатное прикрепление fashion к шасси при старте падало ('Cannot attach given WGVehicleFashion ... yet not
    initialized'). Пробуем повторно, с нарастающей подменой параметров; все шаги пишем в лог."""
    now = BigWorld.time()
    if now < st['next']:
        return
    st['next'] = now + _TRACK_ATTACH_INTERVAL
    st['tries'] += 1
    n = st['tries']
    app = st['app']

    try:
        model = app.modelsDesc['chassis']['model']
    except Exception:
        model = getattr(vehicle, 'model', None)
    if model is None:
        return

    try:
        if hasattr(model, 'wg_fashion'):
            st['attached'] = True
            LOG_DEBUG('tracks: fashion already attached to chassis model (try %d)' % n)
            return
    except Exception:
        pass

    # Ступень 2 (после 3 неудач): подменяем physicsInfo и placingCompensationMatrix своими
    if n == 4:
        try:
            own = _newVec4Provider()
            if own is not None:
                st['fashion'].physicsInfo = own
            st['fashion'].placingCompensationMatrix = Math.Matrix()
            LOG_DEBUG('tracks: physicsInfo / placingCompensationMatrix replaced by own providers')
        except Exception:
            LOG_CURRENT_EXCEPTION()

    # Ступень 3 (после 9 неудач): собираем новый fashion без привязки к нативному фильтру
    if n == 10:
        try:
            import VehicleAppearance as _VA
            f2 = BigWorld.WGVehicleFashion()
            vDesc = vehicle.typeDescriptor
            _VA.setupTracksFashion(f2, vDesc)
            f2.maxMovement = vDesc.physics['speedLimits'][0]
            mv = _newVec4Provider()
            if mv is not None:
                f2.movementInfo = mv
                st['movement'] = mv
            ph = _newVec4Provider()
            if ph is not None:
                f2.physicsInfo = ph
            f2.placingCompensationMatrix = Math.Matrix()
            st['fashion'] = f2
            app._VehicleAppearance__fashion = f2
            LOG_DEBUG('tracks: built a NEW fashion (own providers)')
        except Exception:
            LOG_CURRENT_EXCEPTION()

    try:
        model.wg_fashion = st['fashion']
        st['attached'] = True
        LOG_DEBUG('tracks: fashion attached to chassis model (try %d)' % n)
    except Exception:
        import sys as _sys
        if n <= 3 or n % 10 == 0:
            LOG_DEBUG('tracks: attach try %d failed: %s' % (n, _sys.exc_info()[1]))
        if n >= _TRACK_MAX_ATTACH_TRIES:
            st['attached'] = True
            LOG_ERROR('tracks: giving up attaching fashion after %d tries - tracks will stay static' % n)


class SimpleTankPhysics(object):
    def __init__(self):
        self.vehicle = None

        self.pos = Math.Vector3(0.0, 0.0, 0.0)
        self.yaw = 0.0
        self.pitch = 0.0
        self.roll = 0.0

        self.params = None
        self.flags = 0

        self._cbID = None
        self._groundCbID = None

        self._mprov = None
        self._motorRemoved = False
        self._motorRetryNext = 0.0
        self._mtx = None

        self._lastSpeed = 0.0
        self._curSpeed = 0.0
        self._curRotSpeed = 0.0

        self.isBot = False
        self.tickInterval = 0.0
        self._trk = None
        self._trkTries = 0
        self._trkLog = 0

        self.verticalSpeed = 0.0
        self.lastGroundY = 0.0

        self._lastTime = 0.0
        self._groundReady = False
        self._groundMissCount = 0
        self._tiltLogCount = 0

        # Destructibles state
        self._brokenDestructibles = set()
        self._destDbgCount = 0
        self._destNoDescSeen = set()
        self._chunkDestrCache = {}
        self._chunkDestrCacheSpace = None

    # --------------------------------------------------------
    # Setup
    # --------------------------------------------------------
    def setup(self, vehicle):
        self.vehicle = weakref.proxy(vehicle)

        try:
            p = vehicle.model.position
            self.pos = Math.Vector3(float(p.x), float(p.y), float(p.z))
            self.yaw = float(vehicle.model.yaw)
        except Exception:
            self.pos = Math.Vector3(0.0, 0.0, 0.0)
            self.yaw = 0.0

        self.params = _VehicleParams(vehicle)

        self.flags = 0

        self._cbID = None
        self._groundCbID = None

        self._mprov = None if getattr(self, 'isBot', False) else self._resolveMProv()
        self._motorRemoved = False
        self._motorRetryNext = 0.0
        self._mtx = None

        self.pitch = 0.0
        self.roll = 0.0

        self._lastSpeed = 0.0
        self._curSpeed = 0.0
        self._curRotSpeed = 0.0

        self._trk = None
        self._trkTries = 0
        self._trkLog = 0

        self.verticalSpeed = 0.0
        self.lastGroundY = self.pos.y

        self._lastTime = BigWorld.time()
        self._groundReady = False
        self._groundMissCount = 0
        self._tiltLogCount = 0

        self._brokenDestructibles = set()
        self._destDbgCount = 0
        self._destNoDescSeen = set()
        self._chunkDestrCache = {}
        self._chunkDestrCacheSpace = None

        self._ensureMotorRemoved(vehicle)

        LOG_DEBUG(
            'SimpleTankPhysics setup id=%s pos=(%.1f,%.1f,%.1f) yaw=%.2f' % (
                getattr(vehicle, 'id', None),
                self.pos.x,
                self.pos.y,
                self.pos.z,
                self.yaw,
            )
        )

        self._resolveGround(vehicle, STP_GROUND_RESOLVE_MAX_TRIES)

    # --------------------------------------------------------
    # Start / stop
    # --------------------------------------------------------
    def start(self):
        if self._cbID is not None:
            return

        self._lastTime = BigWorld.time()
        self._cbID = BigWorld.callback(0.0, self._tick)

        LOG_DEBUG('SimpleTankPhysics started: cbID=%s' % self._cbID)

    def stop(self):
        if self._groundCbID is not None:
            try:
                BigWorld.cancelCallback(self._groundCbID)
            except Exception:
                pass

            self._groundCbID = None

        if self._cbID is not None:
            try:
                BigWorld.cancelCallback(self._cbID)
            except Exception:
                pass

            self._cbID = None

    def setFlags(self, flags):
        self.flags = flags

    def getSpeed(self):
        return float(self._curSpeed)

    # --------------------------------------------------------
    # Ground resolve
    # --------------------------------------------------------
    def _resolveGround(self, vehicle, triesLeft):
        try:
            spaceID = vehicle.spaceID
        except Exception:
            spaceID = None

        y = None

        if spaceID is not None:
            y = self._groundHeightStrict(spaceID, self.pos.x, self.pos.y, self.pos.z)

        if y is not None:
            self.pos.y = y
            self.lastGroundY = y
            self._groundReady = True

            LOG_DEBUG(
                'SimpleTankPhysics ground resolved id=%s y=%.2f triesLeft=%d' % (
                    getattr(vehicle, 'id', None),
                    y,
                    triesLeft,
                )
            )

            self.start()
            return

        if triesLeft <= 0:
            LOG_ERROR(
                'SimpleTankPhysics ground resolve timeout id=%s pos=(%.1f,%.1f,%.1f)' % (
                    getattr(vehicle, 'id', None),
                    self.pos.x,
                    self.pos.y,
                    self.pos.z,
                )
            )

            self._groundReady = True
            self.start()
            return

        self._groundCbID = BigWorld.callback(
            STP_GROUND_RESOLVE_DELAY,
            lambda: self._resolveGround(vehicle, triesLeft - 1)
        )

    # --------------------------------------------------------
    # Matrix provider / motor
    # --------------------------------------------------------
    def _resolveMProv(self):
        try:
            avatar = BigWorld.player()
        except Exception:
            return None

        if avatar is None:
            return None

        mp = getattr(avatar, '_PlayerAvatar__ownVehicleMProv', None)
        if mp is not None and callable(getattr(mp, 'setStaticTransform', None)):
            try:
                mp.target = None
            except Exception:
                pass

            return mp

        return None

    def _ensureMotorRemoved(self, vehicle):
        if self._motorRemoved:
            return

        now = BigWorld.time()
        if self._motorRetryNext > now:
            return

        try:
            mdl = getattr(vehicle, 'model', None)
            if mdl is None:
                return

            motors = getattr(mdl, 'motors', None)
            if motors:
                mdl.delMotor(motors[0])

            mtx = Math.Matrix()

            visualPitch = -self.pitch if STP_INVERT_VISUAL_PITCH else self.pitch
            visualRoll = -self.roll if STP_INVERT_VISUAL_ROLL else self.roll

            mtx.setRotateYPR((self.yaw, visualPitch, visualRoll))
            mtx.translation = self.pos

            mdl.addMotor(BigWorld.Servo(mtx))

            self._mtx = mtx
            self._motorRemoved = True

        except Exception:
            LOG_CURRENT_EXCEPTION()
            self._motorRetryNext = now + 1.0

    # --------------------------------------------------------
    # Destructibles: debug / chunk / hide helpers
    # --------------------------------------------------------
    def _destDbg(self, msg):
        if getattr(self, '_destDbgCount', 0) < 200:
            self._destDbgCount = getattr(self, '_destDbgCount', 0) + 1
            LOG_DEBUG('[DESTDBG] %s' % msg)

    def _ensureChunkLoaded(self, spaceID, chunkID):
        mgr = AreaDestructibles.g_destructiblesManager

        if mgr is None:
            return False

        if mgr.isChunkLoaded(chunkID):
            return True

        try:
            filenames = BigWorld.wg_getChunkDestrFilenames(spaceID, chunkID)
        except Exception:
            LOG_CURRENT_EXCEPTION()
            return False

        if filenames is None:
            return False

        try:
            count = len(filenames)
        except Exception:
            try:
                count = int(filenames)
            except Exception:
                return False

        try:
            mgr.onChunkLoad(chunkID, count)
        except Exception:
            LOG_CURRENT_EXCEPTION()

        if mgr.isChunkLoaded(chunkID):
            return True

        try:
            for idx in xrange(count):
                mgr._DestructiblesManager__setDestructibleInitialState(chunkID, idx)

            mgr._DestructiblesManager__loadedChunkIDs[chunkID] = count
        except Exception:
            LOG_CURRENT_EXCEPTION()

        return mgr.isChunkLoaded(chunkID)

    def _hideUnknownDestructible(self, spaceID, chunkID, itemIndex):
        try:
            fashion = BigWorld.wg_getChunkModelFashion(spaceID, chunkID, itemIndex)

            if fashion is None:
                fashion = BigWorld.WGMaterialDisabler()
                BigWorld.wg_setChunkModelFashion(spaceID, chunkID, itemIndex, fashion, True)

            try:
                fashion.isDestroyed = True
            except Exception:
                pass

            try:
                fashion.setEnableDrawMergedModel(False)
            except Exception:
                pass

            try:
                fashion.enableModelCompound = False
            except Exception:
                pass

            try:
                fashion.havokRemove()
            except Exception:
                pass

            return True

        except Exception:
            LOG_CURRENT_EXCEPTION()
            return False

    def _forceFragileHidden(self, spaceID, chunkID, itemIndex):
        mgr = AreaDestructibles.g_destructiblesManager
        if mgr is None:
            return

        try:
            fashion = BigWorld.wg_getChunkModelFashion(spaceID, chunkID, itemIndex)
            if fashion is None:
                fashion = BigWorld.WGMaterialDisabler()
                BigWorld.wg_setChunkModelFashion(spaceID, chunkID, itemIndex, fashion, True)

            try:
                fashion.isDestroyed = True
            except Exception:
                pass
            try:
                fashion.setEnableDrawMergedModel(False)
            except Exception:
                pass
            try:
                fashion.havokRemove()
            except Exception:
                pass
            try:
                fashion.havokDestroyAll()
            except Exception:
                pass
        except Exception:
            LOG_CURRENT_EXCEPTION()

        # 2) Штатный путь — для эффектов и зависимостей.
        try:
            mgr._DestructiblesManager__setDestructibleState(
                spaceID, chunkID, itemIndex, True, None, False
            )
        except Exception:
            LOG_CURRENT_EXCEPTION()

    def _forceStructureHidden(self, spaceID, chunkID, itemIndex):
        try:
            fashion = BigWorld.wg_getChunkModelFashion(spaceID, chunkID, itemIndex)
            if fashion is None:
                fashion = BigWorld.WGMaterialDisabler()
                BigWorld.wg_setChunkModelFashion(spaceID, chunkID, itemIndex, fashion, True)

            try:
                fashion.isDestroyed = True
            except Exception:
                pass
            try:
                fashion.setEnableDrawMergedModel(False)
            except Exception:
                pass
            try:
                fashion.havokRemove()
            except Exception:
                pass
            try:
                fashion.havokDestroyAll()
            except Exception:
                pass
        except Exception:
            LOG_CURRENT_EXCEPTION()

    def _destroyStructureModules(self, spaceID, chunkID, itemIndex, desc, hitMatKind, speed):
        mgr = AreaDestructibles.g_destructiblesManager

        if mgr is None:
            return False

        modules = desc.get('modules') or {}

        if not modules:
            return False

        try:
            hitMatKind = int(hitMatKind)
        except Exception:
            hitMatKind = sorted(modules.keys())[0]

        originalHit = hitMatKind

        if hitMatKind not in modules:
            if DESTRUCTIBLE_MATKIND.DAMAGED_MIN <= hitMatKind <= DESTRUCTIBLE_MATKIND.DAMAGED_MAX:
                normal = hitMatKind - (
                    DESTRUCTIBLE_MATKIND.DAMAGED_MIN - DESTRUCTIBLE_MATKIND.NORMAL_MIN
                )
                if normal in modules:
                    hitMatKind = normal

            if hitMatKind not in modules:
                hitMatKind = sorted(modules.keys())[0]

        filename = (desc.get('filename') or '').lower()

        isFenceLike = any(
            s in filename
            for s in ('fence', 'gate', 'gaf', 'wall', 'zabor')
        )

        destroyAll = (
            isFenceLike
            or len(modules) <= 6
            or speed >= 8.0
            or originalHit not in modules
        )

        if destroyAll:
            matKinds = list(modules.keys())
        else:
            matKinds = [hitMatKind]

        anyDone = False

        for matKind in matKinds:
            try:
                matKind = int(matKind)
            except Exception:
                continue

            key = (
                chunkID,
                itemIndex,
                matKind,
                DestructiblesCache.DESTR_TYPE_STRUCTURE
            )

            if key in self._brokenDestructibles:
                continue

            try:
                data = int(
                    DestructiblesCache.encodeDestructibleModule(
                        itemIndex,
                        matKind,
                        False
                    )
                )

                mgr.orderDestructibleDestroy(
                    chunkID,
                    DestructiblesCache.DESTR_TYPE_STRUCTURE,
                    data,
                    True,
                    syncWithProjectile=False
                )

                self._brokenDestructibles.add(key)
                anyDone = True

            except Exception:
                LOG_CURRENT_EXCEPTION()

        if not anyDone:
            allBroken = True
            for m in modules.keys():
                try:
                    mk = int(m)
                except Exception:
                    continue
                key = (
                    chunkID,
                    itemIndex,
                    mk,
                    DestructiblesCache.DESTR_TYPE_STRUCTURE
                )
                if key not in self._brokenDestructibles:
                    allBroken = False
                    break
            if allBroken:
                return True

        return anyDone

    def _tryDestroyDestructible(self, spaceID, chunkID, itemIndex, matKind, fallYaw, speed):
        mgr = AreaDestructibles.g_destructiblesManager
        cache = AreaDestructibles.g_cache

        if mgr is None or cache is None:
            return False

        try:
            chunkID = int(chunkID)
            itemIndex = int(itemIndex)
            matKind = int(matKind)
        except Exception:
            return False

        if not hasattr(self, '_brokenDestructibles'):
            self._brokenDestructibles = set()

        if not hasattr(self, '_destNoDescSeen'):
            self._destNoDescSeen = set()

        # Принудительная регистрация чанка.
        if not mgr.isChunkLoaded(chunkID):
            try:
                filenames = BigWorld.wg_getChunkDestrFilenames(spaceID, chunkID)
                if filenames is not None:
                    mgr.onChunkLoad(chunkID, len(filenames))
            except Exception:
                LOG_CURRENT_EXCEPTION()

        if not mgr.isChunkLoaded(chunkID):
            return False

        # matKind > 100 обычно у статических неразрушаемых моделей.
        if matKind > DESTRUCTIBLE_MATKIND.MAX:
            return False

        filename = None
        desc = None

        try:
            filename = BigWorld.wg_getDestructibleFilename(spaceID, chunkID, itemIndex)
            if filename:
                import re
                filename = re.sub('/lod./', '/lod0/', filename)
            desc = cache.getDescByFilename(filename)
        except Exception:
            LOG_CURRENT_EXCEPTION()
            return False

        if desc is None:
            noDescKey = (chunkID, itemIndex, filename)
            if noDescKey not in self._destNoDescSeen and len(self._destNoDescSeen) < 25:
                self._destNoDescSeen.add(noDescKey)
                LOG_DEBUG(
                    '[DESTDBG] no desc chunk=%s item=%s matKind=%s file=%s' % (
                        chunkID,
                        itemIndex,
                        matKind,
                        filename,
                    )
                )
            return False

        destrType = desc.get('type')

        # ----------------------------------------------------
        # Structures: fences, gates, small buildings
        # ----------------------------------------------------
        if destrType == DestructiblesCache.DESTR_TYPE_STRUCTURE:
            structKey = (chunkID, itemIndex, 'struct-any')

            if structKey in self._brokenDestructibles:
                return True

            done = self._destroyStructureModules(
                spaceID,
                chunkID,
                itemIndex,
                desc,
                matKind,
                speed
            )

            if done:
                self._brokenDestructibles.add(structKey)
                LOG_DEBUG(
                    '[DEST] ram structure: chunk=%s item=%s matKind=%s spd=%.1f file=%s' % (
                        chunkID,
                        itemIndex,
                        matKind,
                        speed,
                        filename,
                    )
                )

            return done

        # ----------------------------------------------------
        # Fragile: boxes, small fences, crates, barrels, etc.
        # ----------------------------------------------------
        if destrType == DestructiblesCache.DESTR_TYPE_FRAGILE:
            key = (chunkID, itemIndex, destrType)

            if key in self._brokenDestructibles:
                return True

            try:
                data = int(
                    DestructiblesCache.encodeFragile(
                        itemIndex,
                        False
                    )
                )

                mgr.orderDestructibleDestroy(
                    chunkID,
                    destrType,
                    data,
                    True,
                    syncWithProjectile=False
                )

                self._forceFragileHidden(spaceID, chunkID, itemIndex)
                self._brokenDestructibles.add(key)

                LOG_DEBUG(
                    '[DEST] ram fragile: chunk=%s item=%s spd=%.1f file=%s' % (
                        chunkID,
                        itemIndex,
                        speed,
                        filename,
                    )
                )

                return True

            except Exception:
                LOG_CURRENT_EXCEPTION()
                return False

        # ----------------------------------------------------
        # Falling atoms: poles, signs, lamps, etc.
        # ----------------------------------------------------
        if destrType == DestructiblesCache.DESTR_TYPE_FALLING_ATOM:
            key = (chunkID, itemIndex, destrType)

            if key in self._brokenDestructibles:
                return True

            try:
                data = int(
                    DestructiblesCache.encodeFallenColumn(
                        itemIndex,
                        fallYaw,
                        1
                    )
                )

                mgr.orderDestructibleDestroy(
                    chunkID,
                    destrType,
                    data,
                    True,
                    syncWithProjectile=False
                )

                self._brokenDestructibles.add(key)

                LOG_DEBUG(
                    '[DEST] falling atom: chunk=%s item=%s spd=%.1f file=%s' % (
                        chunkID,
                        itemIndex,
                        speed,
                        filename,
                    )
                )

                return True

            except Exception:
                LOG_CURRENT_EXCEPTION()
                return False

        # ----------------------------------------------------
        # Trees
        # ----------------------------------------------------
        if destrType == DestructiblesCache.DESTR_TYPE_TREE:
            key = (chunkID, itemIndex, destrType)

            if key in self._brokenDestructibles:
                return True

            try:
                data = int(
                    DestructiblesCache.encodeFallenTree(
                        itemIndex,
                        fallYaw,
                        math.pi / 2.0,
                        1
                    )
                )

                mgr.orderDestructibleDestroy(
                    chunkID,
                    destrType,
                    data,
                    True,
                    syncWithProjectile=False
                )

                self._brokenDestructibles.add(key)

                LOG_DEBUG(
                    '[DEST] tree: chunk=%s item=%s spd=%.1f file=%s' % (
                        chunkID,
                        itemIndex,
                        speed,
                        filename,
                    )
                )

                return True

            except Exception:
                LOG_CURRENT_EXCEPTION()
                return False

        return False

    # --------------------------------------------------------
    # Destructibles: proximity fallback
    # --------------------------------------------------------
    def _getChunkDestructibles(self, spaceID, chunkID):
        if getattr(self, '_chunkDestrCacheSpace', None) != spaceID:
            self._chunkDestrCache = {}
            self._chunkDestrCacheSpace = spaceID

        if chunkID in self._chunkDestrCache:
            return self._chunkDestrCache[chunkID]

        mgr = AreaDestructibles.g_destructiblesManager
        cache = AreaDestructibles.g_cache

        if mgr is None or cache is None:
            self._chunkDestrCache[chunkID] = []
            return []

        if not self._ensureChunkLoaded(spaceID, chunkID):
            return []

        try:
            filenames = BigWorld.wg_getChunkDestrFilenames(spaceID, chunkID)
        except Exception:
            filenames = None

        if filenames is None:
            self._chunkDestrCache[chunkID] = []
            return []

        try:
            count = len(filenames)
        except Exception:
            try:
                count = int(filenames)
            except Exception:
                count = 0

        if count <= 0:
            self._chunkDestrCache[chunkID] = []
            return []

        try:
            chunkMatrix = BigWorld.wg_getChunkMatrix(spaceID, chunkID)
        except Exception:
            chunkMatrix = None

        if chunkMatrix is None:
            return []

        items = []

        for idx in xrange(count):
            try:
                filename = BigWorld.wg_getDestructibleFilename(spaceID, chunkID, idx)

                if filename:
                    filename = re.sub('/lod./', '/lod0/', filename)

                desc = cache.getDescByFilename(filename)

                m = BigWorld.wg_getDestructibleMatrix(spaceID, chunkID, idx)
                if m is None:
                    continue

                try:
                    pos = chunkMatrix.applyPoint(m.translation)
                except Exception:
                    pos = chunkMatrix.translation + m.translation

                pos = Math.Vector3(pos.x, pos.y, pos.z)

                try:
                    scale = m.applyVector((0.0, 1.0, 0.0)).length
                except Exception:
                    scale = 1.0

                # Unknown destructible: try to hide it later.
                if desc is None:
                    items.append((idx, -1, pos, 1.1, filename))
                    continue

                dtype = desc.get('type')
                fname = (filename or '').lower()

                if dtype == DestructiblesCache.DESTR_TYPE_TREE:
                    radius = max(1.9, 1.2 * scale)

                elif dtype == DestructiblesCache.DESTR_TYPE_FALLING_ATOM:
                    radius = 1.35

                elif dtype == DestructiblesCache.DESTR_TYPE_FRAGILE:
                    radius = 1.45

                elif dtype == DestructiblesCache.DESTR_TYPE_STRUCTURE:
                    # Structures are dangerous to destroy by proximity.
                    # Allow only fence/gate-like objects.
                    if any(s in fname for s in ('fence', 'gate', 'gaf', 'wall', 'zabor')):
                        radius = 2.2
                    else:
                        continue

                else:
                    continue

                items.append((idx, dtype, pos, radius, filename))

            except Exception:
                pass

        self._chunkDestrCache[chunkID] = items
        return items

    def _updateDestructibleProximity(self, vehicle, prevPos, newPos):
        speed = abs(self._curSpeed)

        if speed <= 1.0:
            return

        try:
            spaceID = vehicle.spaceID
        except Exception:
            return

        dx = newPos.x - prevPos.x
        dz = newPos.z - prevPos.z
        dy = newPos.y - prevPos.y

        dist = math.sqrt(dx * dx + dz * dz)

        if dist > 1e-4:
            fallYaw = math.atan2(dx / dist, dz / dist)
        else:
            fallYaw = self.yaw

        samples = max(1, int(dist / 1.0))

        chunkItems = {}

        for i in xrange(samples + 1):
            t = float(i) / float(samples)

            px = prevPos.x + dx * t
            py = prevPos.y + dy * t
            pz = prevPos.z + dz * t

            try:
                chunkID = DestructiblesCache.chunkIDFromPosition((px, py, pz))
            except Exception:
                continue

            if chunkID not in chunkItems:
                chunkItems[chunkID] = self._getChunkDestructibles(spaceID, chunkID)

            items = chunkItems[chunkID]

            if not items:
                continue

            for idx, dtype, pos, radius, filename in items:
                ddx = px - pos.x
                ddz = pz - pos.z

                if ddx * ddx + ddz * ddz <= radius * radius:
                    self._tryDestroyDestructible(
                        spaceID,
                        chunkID,
                        idx,
                        73,
                        fallYaw,
                        speed
                    )

    # --------------------------------------------------------
    # Main tick
    # --------------------------------------------------------
    def _tick(self):
        now = BigWorld.time()
        dt = now - self._lastTime
        self._lastTime = now

        self._cbID = BigWorld.callback(getattr(self, 'tickInterval', 0.0), self._tick)

        if dt <= 0.0:
            return

        if dt > 0.1:
            dt = 0.1

        try:
            vehicle = self.vehicle
        except Exception:
            self.stop()
            return

        if vehicle is None or not getattr(vehicle, 'isStarted', False):
            self.stop()
            return

        if not getattr(self, '_groundReady', True):
            return

        prevPos = Math.Vector3(self.pos)

        self._updateMovement(vehicle, dt)
        self._updateCollision(vehicle, dt)
        self._updateDestructibleProximity(vehicle, prevPos, self.pos)
        self._updateGroundFollow(vehicle, dt)
        self._updateTilt(vehicle, dt)

        self._lastSpeed = self._curSpeed
        self._apply(vehicle)
        _updateVehicleEngineSound(vehicle)

    # --------------------------------------------------------
    # Movement
    # --------------------------------------------------------
    def _updateMovement(self, vehicle, dt):
        # во время обратного отсчёта танк стоит на месте (башня/прицел работают)
        flags = 0 if isPrebattle() else self.flags

        moveDir = 0
        if flags & 1:
            moveDir = 1
        elif flags & 2:
            moveDir = -1

        rotDir = 0
        if flags & 4:
            rotDir = -1
        elif flags & 8:
            rotDir = 1

        params = self.params

        if moveDir > 0:
            targetSpeed = params.maxFwd
        elif moveDir < 0:
            targetSpeed = -params.maxBack
        else:
            targetSpeed = 0.0

        if moveDir != 0:
            accelRate = params.accel
        else:
            accelRate = params.brake

        self._curSpeed = self._approach(self._curSpeed, targetSpeed, accelRate, dt)
        self._curSpeed -= self._curSpeed * params.terrainDrag * dt

        if self._curSpeed > 0.0:
            self._curSpeed = min(self._curSpeed, params.maxFwd)
        elif self._curSpeed < 0.0:
            self._curSpeed = max(self._curSpeed, -params.maxBack)

        if abs(self._curSpeed) < 1e-3:
            self._curSpeed = 0.0

        targetRot = rotDir * params.rotRate

        if rotDir != 0:
            rotRate = params.rotAccel
        else:
            rotRate = params.rotDecel

        self._curRotSpeed = self._approach(self._curRotSpeed, targetRot, rotRate, dt)

        if abs(self._curRotSpeed) < 1e-3:
            self._curRotSpeed = 0.0

        self.yaw += self._curRotSpeed * dt

    # --------------------------------------------------------
    # Collision
    # --------------------------------------------------------
    def _updateCollision(self, vehicle, dt):
        if abs(self._curSpeed) <= 1e-4:
            return

        fwd = Math.Vector3(
            math.sin(self.yaw),
            0.0,
            math.cos(self.yaw)
        )

        candidate = self.pos + fwd * (self._curSpeed * dt)

        try:
            spaceID = vehicle.spaceID
            candidate.y = self._groundHeight(
                spaceID,
                candidate.x,
                self.pos.y,
                candidate.z,
                self.pos.y
            )
        except Exception:
            pass

        self.pos = self._checkCollision(vehicle, candidate)

    def _checkCollision(self, vehicle, candidate):
        try:
            spaceID = vehicle.spaceID
        except Exception:
            return candidate

        dx = candidate.x - self.pos.x
        dz = candidate.z - self.pos.z

        dist = math.sqrt(dx * dx + dz * dz)
        if dist < 1e-4:
            return candidate

        dirX = dx / dist
        dirZ = dz / dist

        fwd = Math.Vector3(dirX, 0.0, dirZ)
        right = Math.Vector3(dirZ, 0.0, -dirX)

        params = self.params
        probeDist = dist + STP_COLLIDE_MARGIN

        baseYStart = self.pos.y
        baseYEnd = candidate.y

        if spaceID is not None:
            g0 = self._groundHeight(spaceID, self.pos.x, self.pos.y, self.pos.z, self.pos.y)
            g1 = self._groundHeight(spaceID, candidate.x, g0, candidate.z, g0)

            lift = max(STP_COLLIDE_BASE_LIFT_MIN, params.clearance * 0.65)

            baseYStart = g0 + lift
            baseYEnd = g1 + lift

        offsets = (
            (0.0, 0.0),
            (params.halfLength, 0.0),
            (-params.halfLength, 0.0),
            (0.0, params.halfWidth),
            (0.0, -params.halfWidth),
            (params.halfLength, params.halfWidth),
            (params.halfLength, -params.halfWidth),
            (-params.halfLength, params.halfWidth),
            (-params.halfLength, -params.halfWidth),
        )

        bestT = probeDist
        bestNormal = None

        for longOff, latOff in offsets:
            baseX = self.pos.x + fwd.x * longOff + right.x * latOff
            baseZ = self.pos.z + fwd.z * longOff + right.z * latOff

            for h in STP_COLLIDE_HEIGHTS:
                start = Math.Vector3(baseX, baseYStart + h, baseZ)
                end = Math.Vector3(
                    baseX + dirX * probeDist,
                    baseYEnd + h,
                    baseZ + dirZ * probeDist
                )

                try:
                    # Static collision
                    res = BigWorld.wg_collideSegment(spaceID, start, end, 0)

                    # Destructibles collision
                    res_dest = BigWorld.wg_collideSegment(spaceID, start, end, 128)

                    if res_dest is not None:
                        try:
                            if len(res_dest) > 5:
                                destMatKind = res_dest[2]
                                destItemIndex = res_dest[4]
                                destChunkID = res_dest[5]

                                speed = abs(self._curSpeed)

                                if speed > 1.0:
                                    fallYaw = math.atan2(dirX, dirZ)

                                    if self._tryDestroyDestructible(
                                        spaceID,
                                        destChunkID,
                                        destItemIndex,
                                        destMatKind,
                                        fallYaw,
                                        speed
                                    ):
                                        continue

                        except Exception:
                            LOG_CURRENT_EXCEPTION()

                except Exception:
                    LOG_CURRENT_EXCEPTION()
                    res = None

                if res is None:
                    continue

                hitPoint = res[0]
                if hitPoint is None:
                    continue

                n = None
                if len(res) > 1:
                    n = self._asVector3(res[1])

                if n is not None and abs(n.y) > STP_COLLIDE_GROUND_NORMAL_IGNORE:
                    continue

                hx = hitPoint.x - start.x
                hz = hitPoint.z - start.z

                t = hx * dirX + hz * dirZ
                if t < 0.0:
                    continue

                if t < bestT:
                    bestT = t
                    bestNormal = n

        if bestT >= dist:
            return candidate

        if bestT <= STP_COLLIDE_MARGIN:
            self._curSpeed *= 0.25
            return self.pos

        allowed = max(0.0, bestT - STP_COLLIDE_MARGIN)

        newPos = Math.Vector3(
            self.pos.x + dirX * allowed,
            self.pos.y,
            self.pos.z + dirZ * allowed
        )

        remaining = candidate - newPos

        if bestNormal is not None:
            n = Math.Vector3(bestNormal.x, 0.0, bestNormal.z)

            if n.length > 1e-5:
                n.normalise()

                dot = self._dotV3(remaining, n)
                if dot < 0.0:
                    remaining = remaining - n * dot

                newPos = newPos + remaining * 0.5

            self._curSpeed *= 0.7
        else:
            self._curSpeed *= 0.4

        return newPos

    # --------------------------------------------------------
    # Ground follow
    # --------------------------------------------------------
    def _updateGroundFollow(self, vehicle, dt):
        try:
            spaceID = vehicle.spaceID
        except Exception:
            return

        targetY = self._groundHeight(
            spaceID,
            self.pos.x,
            self.pos.y,
            self.pos.z,
            self.lastGroundY
        )

        self.lastGroundY = targetY

        if STP_USE_SMOOTH_GROUND:
            alpha = 1.0 - math.exp(-STP_GROUND_FOLLOW_RATE * dt)
            self.pos.y += (targetY - self.pos.y) * alpha
        else:
            self.pos.y = targetY

        self.verticalSpeed = 0.0

    # --------------------------------------------------------
    # Tilt
    # --------------------------------------------------------
    def _computeTilt(self, vehicle):
        try:
            spaceID = vehicle.spaceID
        except Exception:
            return 0.0, 0.0

        params = self.params

        cosY = math.cos(self.yaw)
        sinY = math.sin(self.yaw)

        fx = sinY * params.halfLength
        fz = cosY * params.halfLength

        rx = cosY * params.halfWidth
        rz = -sinY * params.halfWidth

        px = self.pos.x
        pz = self.pos.z
        py = self.pos.y

        frontY = self._groundHeight(spaceID, px + fx, py, pz + fz, py)
        rearY = self._groundHeight(spaceID, px - fx, py, pz - fz, py)
        leftY = self._groundHeight(spaceID, px - rx, py, pz - rz, py)
        rightY = self._groundHeight(spaceID, px + rx, py, pz + rz, py)

        pitch = math.atan2(frontY - rearY, 2.0 * params.halfLength)
        roll = math.atan2(leftY - rightY, 2.0 * params.halfWidth)

        if self._tiltLogCount < 3:
            self._tiltLogCount += 1
            LOG_DEBUG(
                'SimpleTankPhysics tilt #%d: front=%.2f rear=%.2f left=%.2f right=%.2f pitch=%.3f roll=%.3f' % (
                    self._tiltLogCount,
                    frontY,
                    rearY,
                    leftY,
                    rightY,
                    pitch,
                    roll,
                )
            )

        return pitch, roll

    def _updateTilt(self, vehicle, dt):
        try:
            targetPitch, targetRoll = self._computeTilt(vehicle)

            targetPitch = self._clamp(-STP_MAX_PITCH, STP_MAX_PITCH, targetPitch)
            targetRoll = self._clamp(-STP_MAX_ROLL, STP_MAX_ROLL, targetRoll)

            if STP_PITCH_RESPONSE <= 0.0:
                self.pitch = targetPitch
            else:
                pitchAlpha = 1.0 - math.exp(-STP_PITCH_RESPONSE * dt)
                self.pitch += (targetPitch - self.pitch) * pitchAlpha

            if STP_ROLL_RESPONSE <= 0.0:
                self.roll = targetRoll
            else:
                rollAlpha = 1.0 - math.exp(-STP_ROLL_RESPONSE * dt)
                self.roll += (targetRoll - self.roll) * rollAlpha

        except Exception:
            LOG_CURRENT_EXCEPTION()

    # --------------------------------------------------------
    # Apply matrix
    # --------------------------------------------------------
    def _apply(self, vehicle):
        self._ensureMotorRemoved(vehicle)

        visualPitch = -self.pitch if STP_INVERT_VISUAL_PITCH else self.pitch
        visualRoll = -self.roll if STP_INVERT_VISUAL_ROLL else self.roll

        if self._mtx is not None:
            self._mtx.setRotateYPR((self.yaw, visualPitch, visualRoll))
            self._mtx.translation = self.pos

        if self._mprov is not None:
            try:
                self._mprov.target = None
            except Exception:
                pass

            try:
                mtx = Math.Matrix()
                mtx.setRotateYPR((self.yaw, visualPitch, visualRoll))
                mtx.translation = self.pos

                self._mprov.setStaticTransform(mtx)

            except Exception:
                self._mprov = None

        try:
            filt = getattr(vehicle, 'filter', None)
            if filt is not None and hasattr(filt, 'setPosition'):
                filt.setPosition(self.pos.x, self.pos.z)
        except Exception:
            LOG_CURRENT_EXCEPTION()

        self._updateTrackAnimation(vehicle)

    def _updateTrackAnimation(self, vehicle):
        if getattr(self, 'isBot', False):
            return
        try:
            if self._trk is None:
                if self._trkTries >= _TRACK_MAX_INIT_TRIES:
                    return
                self._trkTries += 1
                self._trk = _initTrackAnimation(vehicle)
                if self._trk is None:
                    return

            st = self._trk
            if not st['attached']:
                _attachTrackFashion(vehicle, st)

            v = float(self._curSpeed)
            w = float(self._curRotSpeed)
            hw = float(getattr(self.params, 'halfWidth', 1.5))
            vmax = max(float(getattr(self.params, 'maxFwd', 15.0)), 0.1)

            turn = w * hw
            if TRACK_INVERT_TURN:
                turn = -turn
            left = v + turn
            right = v - turn
            fwd = v
            if not TRACK_UNITS_ABS:
                left = max(-1.0, min(1.0, left / vmax))
                right = max(-1.0, min(1.0, right / vmax))
                fwd = max(-1.0, min(1.0, fwd / vmax))
            if TRACK_INVERT_SCROLL:
                left, right, fwd = -left, -right, -fwd

            mp = st.get('movement')
            if mp is not None:
                mp.value = Math.Vector4(fwd, left, right, 0.0)
            sp = st.get('speed')
            if sp is not None:
                sp.value = Math.Vector4(v, w, v, 0.0)

            if self._trkLog < 3 and abs(v) > 0.5:
                self._trkLog += 1
                LOG_DEBUG('tracks: v=%.2f w=%.2f -> movementInfo=(%.2f, %.2f, %.2f) readback=%s attached=%s' % (
                    v, w, fwd, left, right, mp.value if mp is not None else None, st['attached']))
        except Exception:
            self._trkTries = _TRACK_MAX_INIT_TRIES
            LOG_CURRENT_EXCEPTION()

    # --------------------------------------------------------
    # Ground helpers
    # --------------------------------------------------------
    def _groundHeight(self, spaceID, x, y, z, fallback):
        try:
            start = Math.Vector3(x, y + STP_GROUND_RAY_UP, z)
            end = Math.Vector3(x, y - STP_GROUND_RAY_DOWN, z)

            res = BigWorld.wg_collideSegment(spaceID, start, end, 0)
            if res is not None:
                return float(res[0].y)

            start = Math.Vector3(x, y + STP_GROUND_RAY_WIDE_UP, z)
            end = Math.Vector3(x, y - STP_GROUND_RAY_WIDE_DOWN, z)

            res = BigWorld.wg_collideSegment(spaceID, start, end, 0)
            if res is not None:
                return float(res[0].y)

            if self._groundMissCount < 10:
                self._groundMissCount += 1
                LOG_DEBUG(
                    'SimpleTankPhysics ground miss #%d: spaceID=%s x=%.2f z=%.2f fallback=%.2f' % (
                        self._groundMissCount,
                        spaceID,
                        x,
                        z,
                        fallback,
                    )
                )

        except Exception:
            LOG_CURRENT_EXCEPTION()

        return float(fallback)

    def _groundHeightStrict(self, spaceID, x, y, z):
        try:
            start = Math.Vector3(x, y + STP_GROUND_RAY_UP, z)
            end = Math.Vector3(x, y - STP_GROUND_RAY_DOWN, z)

            res = BigWorld.wg_collideSegment(spaceID, start, end, 0)
            if res is not None:
                return float(res[0].y)

            start = Math.Vector3(x, y + STP_GROUND_RAY_WIDE_UP, z)
            end = Math.Vector3(x, y - STP_GROUND_RAY_WIDE_DOWN, z)

            res = BigWorld.wg_collideSegment(spaceID, start, end, 0)
            if res is not None:
                return float(res[0].y)

        except Exception:
            LOG_CURRENT_EXCEPTION()

        return None

    # --------------------------------------------------------
    # Math helpers
    # --------------------------------------------------------
    @staticmethod
    def _approach(current, target, rate, dt):
        diff = target - current
        maxStep = rate * dt

        if diff > maxStep:
            return current + maxStep

        if diff < -maxStep:
            return current - maxStep

        return target

    @staticmethod
    def _clamp(minValue, maxValue, value):
        if value < minValue:
            return minValue

        if value > maxValue:
            return maxValue

        return value

    @staticmethod
    def _dotV3(a, b):
        return a.x * b.x + a.y * b.y + a.z * b.z

    @staticmethod
    def _asVector3(value):
        try:
            return Math.Vector3(
                float(value[0]),
                float(value[1]),
                float(value[2])
            )
        except Exception:
            return None


_SimplePhysics = SimpleTankPhysics

# ============================================================
# Arena period / countdown
# ============================================================
# Время до начала боя (обратный отсчёт) и длительность самого боя, сек.
PREBATTLE_LENGTH = 30.0
BATTLE_LENGTH = 15 * 60.0

_PREBATTLE_ACTIVE = False   # True пока идёт обратный отсчёт (стоять и не стрелять)
_COUNTDOWN_TOKEN = 0        # id текущего отсчёта; старые callback-и с другим id игнорируются
_COUNTDOWN_AVATAR = None


def isPrebattle():
    return _BATTLE_ACTIVE and _PREBATTLE_ACTIVE


_SERVER_TIME_PATCHED = False


def _patchServerTime():
    # Оффлайн BigWorld.serverTime() возвращает константу (-1.0), поэтому таймеры боя
    # (periodEndTime - serverTime()) стояли на месте. В бою отдаём BigWorld.time().
    global _SERVER_TIME_PATCHED
    if _SERVER_TIME_PATCHED:
        return
    try:
        orig = BigWorld.serverTime

        def serverTime(orig=orig):
            if _BATTLE_ACTIVE:
                return BigWorld.time()
            return orig()

        BigWorld.serverTime = serverTime
        _SERVER_TIME_PATCHED = True
        LOG_DEBUG('BigWorld.serverTime patched (battle clock runs offline)')
    except Exception:
        LOG_CURRENT_EXCEPTION()


def _arenaNow():
    # ВАЖНО: клиентский Battle.__setArenaTime считает остаток времени как
    #   arena.periodEndTime - BigWorld.serverTime()
    # поэтому endTime обязан быть в тех же часах (serverTime), а не BigWorld.time().
    try:
        return BigWorld.serverTime()
    except Exception:
        LOG_CURRENT_EXCEPTION()
        return BigWorld.time()


def _forceArenaPeriod(avatar, period, length, additionalInfo=None):
    try:
        endTime = _arenaNow() + length
        payload = cPickle.dumps((period, endTime, length, additionalInfo))
        avatar.arena.update(ARENA_UPDATE.PERIOD, payload)
        LOG_DEBUG('battle: forced arena period=%s length=%s endTime=%.2f serverTime=%.2f time=%.2f' % (
            period, length, endTime, _arenaNow(), BigWorld.time()))
    except Exception:
        LOG_CURRENT_EXCEPTION()


def _finishPrebattle(avatar, token):
    global _PREBATTLE_ACTIVE
    from constants import ARENA_PERIOD

    # отсчёт устарел (бой закрыли / начали новый) - ничего не делаем
    if token != _COUNTDOWN_TOKEN or not _BATTLE_ACTIVE:
        LOG_DEBUG('battle: stale countdown callback ignored (token=%s)' % token)
        return

    _PREBATTLE_ACTIVE = False
    _forceArenaPeriod(avatar, ARENA_PERIOD.BATTLE, BATTLE_LENGTH)
    LOG_DEBUG('battle: PREBATTLE finished -> BATTLE started')


def _startPrebattleCountdown(avatar):
    global _PREBATTLE_ACTIVE, _COUNTDOWN_TOKEN, _COUNTDOWN_AVATAR
    from constants import ARENA_PERIOD

    # защита от двойного запуска для одного и того же боя
    if _PREBATTLE_ACTIVE and _COUNTDOWN_AVATAR is avatar:
        return

    _COUNTDOWN_TOKEN += 1
    token = _COUNTDOWN_TOKEN
    _COUNTDOWN_AVATAR = avatar
    _PREBATTLE_ACTIVE = True

    _forceArenaPeriod(avatar, ARENA_PERIOD.PREBATTLE, PREBATTLE_LENGTH)
    BigWorld.callback(PREBATTLE_LENGTH, lambda: _finishPrebattle(avatar, token))


def _resetCountdown():
    global _PREBATTLE_ACTIVE, _COUNTDOWN_TOKEN, _COUNTDOWN_AVATAR
    _COUNTDOWN_TOKEN += 1
    _PREBATTLE_ACTIVE = False
    _COUNTDOWN_AVATAR = None

# ============================================================
# Vehicle / avatar patches
# ============================================================
def _patchVehicleNativePhysics():
    try:
        import Vehicle as _Veh

        cls = _Veh.Vehicle

        _orig_startPhysics = cls._Vehicle__startWGPhysics

        def _safe_startPhysics(self, orig=_orig_startPhysics):
            if _BATTLE_ACTIVE:
                LOG_DEBUG(
                    'vehicle native physics skipped (offline), id=%s' % getattr(self, 'id', None)
                )

                self.wgPhysics = None

                try:
                    sp = SimpleTankPhysics()

                    # чужие машины (боты) не должны трогать матрицу/камеру игрока
                    try:
                        ownID = getattr(BigWorld.player(), 'playerVehicleID', 0)
                        isBot = False
                        try:
                            isBot = int(self.publicInfo['accountDBID']) < 0
                        except Exception:
                            isBot = bool(ownID) and self.id != ownID
                        if isBot:
                            sp.isBot = True
                            sp.tickInterval = 0.04
                    except Exception:
                        LOG_CURRENT_EXCEPTION()

                    sp.setup(self)

                    _simplePhysicsByVehID[self.id] = sp
                    sp.start()

                except Exception:
                    LOG_CURRENT_EXCEPTION()

                return

            return orig(self)

        cls._Vehicle__startWGPhysics = _safe_startPhysics

        _orig_stopPhysics = cls._Vehicle__stopWGPhysics

        def _safe_stopPhysics(self, orig=_orig_stopPhysics):
            sp = _simplePhysicsByVehID.pop(getattr(self, 'id', None), None)
            if sp is not None:
                try:
                    sp.stop()
                except Exception:
                    LOG_CURRENT_EXCEPTION()

            turretCtrl = _simpleTurretByVehID.pop(getattr(self, 'id', None), None)
            if turretCtrl is not None:
                try:
                    turretCtrl.stop()
                except Exception:
                    LOG_CURRENT_EXCEPTION()

            if _BATTLE_ACTIVE and getattr(self, 'wgPhysics', None) is None:
                return

            return orig(self)

        cls._Vehicle__stopWGPhysics = _safe_stopPhysics

        LOG_DEBUG('Vehicle native physics offline-safe patch installed')

    except Exception:
        LOG_CURRENT_EXCEPTION()

def _patchAvatarInputHandlerDetach():
    try:
        import AvatarInputHandler

        _orig_detachCursor = AvatarInputHandler.AvatarInputHandler.detachCursor

        def _safe_detachCursor(self, isDetached, enableAiming):
            if _isOffline() and isDetached:
                LOG_DEBUG('detachCursor(True) suppressed (offline)')
                return
            return _orig_detachCursor(self, isDetached, enableAiming)

        AvatarInputHandler.AvatarInputHandler.detachCursor = _safe_detachCursor
        LOG_DEBUG('AvatarInputHandler.detachCursor offline-safe patch installed')
    except Exception:
        LOG_CURRENT_EXCEPTION()

def _patchVehicleAppearanceHavok():
    try:
        import VehicleAppearance as _VA

        cls = _VA.VehicleAppearance

        _orig_setupHavok = cls._VehicleAppearance__setupHavok

        def _safe_setupHavok(self, orig=_orig_setupHavok):
            if _BATTLE_ACTIVE:
                LOG_DEBUG('vehicle havok setup skipped (offline)')
                return

            return orig(self)

        cls._VehicleAppearance__setupHavok = _safe_setupHavok

        LOG_DEBUG('VehicleAppearance havok offline-safe patch installed')

    except Exception:
        LOG_CURRENT_EXCEPTION()


def _patchVehicleStartVisual():
    try:
        import Vehicle as _Veh

        cls = _Veh.Vehicle

        _orig = cls.startVisual

        def _safe_startVisual(self, orig=_orig):
            if not _BATTLE_ACTIVE:
                return orig(self)

            try:
                from gui.mods.offhangar import bots as off_bots
                off_bots.preStartVisual(self)
            except Exception:
                LOG_CURRENT_EXCEPTION()

            try:
                orig(self)
            except Exception:
                LOG_CURRENT_EXCEPTION()

                # Minimal fallback without native/sound-related calls.
                try:
                    self.appearance.preStart(self.typeDescriptor)
                    self.appearance.start(self, self._Vehicle__prereqs)

                    self._Vehicle__prereqs = None
                    self.appearance.onVehicleHealthChanged()

                    self.isStarted = True
                    self._Vehicle__startWGPhysics()

                except Exception:
                    LOG_CURRENT_EXCEPTION()

            if self.isPlayer:
                ctrl = _simpleTurretByVehID.get(self.id)
                if ctrl is not None:
                    try:
                        self.appearance.setupGunMatrixTargets(ctrl)
                        LOG_DEBUG('turret rotation target attached id=%s' % self.id)
                    except Exception:
                        LOG_CURRENT_EXCEPTION()

        cls.startVisual = _safe_startVisual

        LOG_DEBUG('Vehicle.startVisual offline-safe patch installed')

    except Exception:
        LOG_CURRENT_EXCEPTION()


def _patchEdgeDetect():
    try:
        _orig_add = BigWorld.wgAddEdgeDetectEntity
        _orig_del = BigWorld.wgDelEdgeDetectEntity

        def _safe_add(*args, **kwargs):
            if _BATTLE_ACTIVE:
                return

            return _orig_add(*args, **kwargs)

        def _safe_del(*args, **kwargs):
            if _BATTLE_ACTIVE:
                return

            return _orig_del(*args, **kwargs)

        BigWorld.wgAddEdgeDetectEntity = _safe_add
        BigWorld.wgDelEdgeDetectEntity = _safe_del

        LOG_DEBUG('EdgeDetect offline-safe patch installed')

    except Exception:
        LOG_CURRENT_EXCEPTION()


def _patchSplineTracks():
    try:
        import VehicleAppearance as _VA

        _orig = _VA.setupSplineTracks

        def _safe_setupSplineTracks(fashion, vDesc, chassisModel, prereqs):
            try:
                splineDesc = getattr(vDesc.chassis, 'splineDesc', None)
                # nothing to do if no spline description
                if splineDesc is None:
                    return None

                # need BigWorld helper available
                if not hasattr(BigWorld, 'wg_createSplineTrack'):
                    LOG_DEBUG('wg_createSplineTrack not available, skipping spline tracks')
                    return None

                # prereqs must contain required segment models
                if prereqs is None:
                    LOG_DEBUG('prereqs missing, skipping spline tracks')
                    return None

                leftName = splineDesc.get('segmentModelLeft')
                rightName = splineDesc.get('segmentModelRight')
                if leftName not in prereqs or rightName not in prereqs:
                    LOG_DEBUG('spline segment models not in prereqs, skipping spline tracks')
                    return None

                return _orig(fashion, vDesc, chassisModel, prereqs)
            except Exception:
                LOG_CURRENT_EXCEPTION()
                return None

        _VA.setupSplineTracks = _safe_setupSplineTracks

        LOG_DEBUG('SplineTracks offline-safe patch installed')

    except Exception:
        LOG_CURRENT_EXCEPTION()


def _patchAvatarMoveVehicle():
    try:
        import Avatar as _A

        cls = _A.PlayerAvatar

        _orig_moveVehicle = cls.moveVehicle

        def _safe_moveVehicle(self, flags, isKeyDown, orig=_orig_moveVehicle):
            if _BATTLE_ACTIVE:
                flags = int(flags or 0)

                sp = _simplePhysicsByVehID.get(self.playerVehicleID)
                if sp is not None:
                    sp.setFlags(flags)

                try:
                    vehicle = BigWorld.entity(self.playerVehicleID)

                    if vehicle is not None and getattr(vehicle, 'isStarted', False):
                        try:
                            vehicle.showPlayerMovementCommand(flags)
                        except Exception:
                            pass

                        try:
                            movementDir = 1 if flags & 1 else (-1 if flags & 2 else 0)
                            rotationDir = -1 if flags & 4 else (1 if flags & 8 else 0)

                            vehicle.filter.notifyInputKeysDown(movementDir, rotationDir)

                        except Exception:
                            LOG_CURRENT_EXCEPTION()

                except Exception:
                    LOG_CURRENT_EXCEPTION()

                return

            return orig(self, flags, isKeyDown)

        cls.moveVehicle = _safe_moveVehicle

        LOG_DEBUG('Avatar.moveVehicle offline-safe patch installed')

    except Exception:
        LOG_CURRENT_EXCEPTION()


def _patchAvatarPositionControl():
    try:
        import AvatarPositionControl as _APC
        cls = _APC.AvatarPositionControl

        _orig_moveTo = cls.moveTo

        def _safe_moveTo(self, pos):
            if _isOffline():
                return
            return _orig_moveTo(self, pos)

        cls.moveTo = _safe_moveTo

        LOG_DEBUG('AvatarPositionControl offline-safe patch installed')
    except Exception:
        LOG_CURRENT_EXCEPTION()


def _patchAvatarBaseCell():
    try:
        import Avatar as _A

        cls = _A.PlayerAvatar

        origGA = cls.__getattribute__

        def _patchedGA(self, name, orig=origGA):
            if name in ('base', 'cell', 'server') and _BATTLE_ACTIVE:
                return _AVATAR_FAKE_SERVER

            try:
                return orig(self, name)
            except AttributeError:
                if _BATTLE_ACTIVE and name in _OFFLINE_ATTR_DEFAULTS:
                    return _OFFLINE_ATTR_DEFAULTS[name]

                raise

        cls.__getattribute__ = _patchedGA

        LOG_DEBUG('Avatar base/cell offline-safe patch installed')

    except Exception:
        LOG_CURRENT_EXCEPTION()


def _patchAvatarOwnVehicleMatrix():
    try:
        import Avatar as _A

        cls = _A.PlayerAvatar

        _orig = cls._PlayerAvatar__setOwnVehicleMatrixCallback

        def _safe_setOwnVehicleMatrixCallback(self, orig=_orig):
            if _BATTLE_ACTIVE:
                mp = getattr(self, '_PlayerAvatar__ownVehicleMProv', None)
                if mp is not None:
                    try:
                        mp.target = None
                    except Exception:
                        pass

                return

            return orig(self)

        cls._PlayerAvatar__setOwnVehicleMatrixCallback = _safe_setOwnVehicleMatrixCallback

        LOG_DEBUG('Avatar.__setOwnVehicleMatrixCallback offline patch installed')

    except Exception:
        LOG_CURRENT_EXCEPTION()


# ============================================================
# Offline battle helpers
# ============================================================
class _PublicInfo(dict):
    def __init__(self, compDescr, team):
        data = {
            'compDescr': compDescr,
            'team': team,
            'isTeamKiller': False,
            'index': 0,
            'name': OFFLINE_NICKNAME,
            'prebattleID': 0,
            'marksOnGun': 0,
            'accountDBID': OFFLINE_DBID,
            'clanAbbrev': '',
            'clanDBID': 0,
            'isPrebattleCreator': False,
            'events': {},
            'igrType': 0,
            'potapovQuestIDs': [],
            'vehicleType': None,
        }

        dict.__init__(self, data)

        for k, v in data.items():
            setattr(self, k, v)


def _chooseArenaTypeID():
    candidates = [
        tid for tid, at in ArenaType.g_cache.items()
        if getattr(at, 'gameplayName', '') == 'ctf'
        and not getattr(at, 'explicitRequestOnly', False)
    ]

    if not candidates:
        candidates = list(ArenaType.g_cache.keys())

    return random.choice(candidates) if candidates else None


def _spawnPos(at):
    path = 'scripts/arena_defs/%s.xml' % at.geometryName

    try:
        section = ResMgr.openSection(path)

        if section is not None:
            basePositions = section['gameplayTypes/ctf/teamBasePositions/team1']

            if basePositions is not None:
                posStr = basePositions.readString('position1', '')

                if posStr:
                    parts = posStr.split()

                    if len(parts) >= 2:
                        x = float(parts[0])
                        z = float(parts[1])

                        LOG_DEBUG('spawnPos from xml: x=%.2f z=%.2f' % (x, z))

                        return (x, 0.0, z)

    except Exception:
        LOG_CURRENT_EXCEPTION()

    return (0.0, 0.0, 0.0)


def _vehInfoTuple(vid, compDescr, team):
    return (
        vid,
        compDescr,
        OFFLINE_NICKNAME,
        team,
        True,
        True,
        False,
        OFFLINE_DBID,
        '',
        0,
        0,
        False,
        {},
        0,
        [],
    )


def _getMaxHealth(compDescr):
    try:
        from items import vehicles as _vehicles_module

        descr = _vehicles_module.VehicleDescr(compactDescr=compDescr)
        return descr.maxHealth

    except Exception:
        LOG_CURRENT_EXCEPTION()

    return 1000


# ============================================================
# Avatar init / world enter / leave
# ============================================================
def _offlineInitStep(self, *args, **kwargs):
    if not _BATTLE_ACTIVE:
        if _ORIG_INIT_STEP:
            return _ORIG_INIT_STEP(self, *args, **kwargs)

        return

    steps = getattr(self, '_PlayerAvatar__stepsTillInit', 0)

    if not steps or steps <= 0:
        return

    self._PlayerAvatar__stepsTillInit = steps - 1

    if self._PlayerAvatar__stepsTillInit != 0:
        return

    LOG_DEBUG('battle: init-step finalize begin')

    try:
        self.initSpace()
    except Exception:
        LOG_CURRENT_EXCEPTION()

    try:
        LOG_DEBUG('battle: calling startGUI')
        self._PlayerAvatar__startGUI()
        LOG_DEBUG('battle: startGUI done')
    except Exception:
        LOG_CURRENT_EXCEPTION()

    try:
        import Vehicle as _V

        for v in BigWorld.entities.values():
            if (
                getattr(v, 'inWorld', False)
                and isinstance(v, _V.Vehicle)
                and not v.isStarted
            ):
                LOG_DEBUG('battle: startVisual for vehicle id=%s' % v.id)

                v.startVisual()
                self.onVehicleEnterWorld(v)

    except Exception:
        LOG_CURRENT_EXCEPTION()

    try:
        from helpers import DecalMap

        DecalMap.g_instance.initGroups(1.0)
        self._PlayerAvatar__setOwnVehicleMatrixCallback()

    except Exception:
        LOG_CURRENT_EXCEPTION()

    try:
        BigWorld.worldDrawEnabled(True)

        import BattleReplay
        BattleReplay.g_replayCtrl.onClientReady()

    except Exception:
        LOG_CURRENT_EXCEPTION()

    try:
        self._PlayerAvatar__setIsOnArena(True)

        own = BigWorld.entity(self.playerVehicleID)
        if own is not None:
            self.updateVehicleHealth(own.health, own.isCrewActive)

    except Exception:
        LOG_CURRENT_EXCEPTION()

    try:
        from Avatar import ClientVisibilityFlags
        ClientVisibilityFlags.updateSpaceVisibility(self.spaceID, 0)

        from PlayerEvents import g_playerEvents
        g_playerEvents.onAvatarReady()

    except Exception:
        LOG_CURRENT_EXCEPTION()

    LOG_DEBUG('battle: finalize done; userSeesWorld=%s' % self.userSeesWorld())


def _onEnterWorld(self, prereqs):
    global _PENDING_CTX

    if _BATTLE_ACTIVE and _PENDING_CTX is not None:
        props, at, compDescr, spaceID, ammoDict, hangarVehicle, vehInvID = _PENDING_CTX

        if getattr(self, 'spaceID', None) == spaceID:
            for k, v in props.items():
                try:
                    setattr(self, k, v)
                except Exception:
                    pass

            if BigWorld.player() is not self:
                try:
                    BigWorld.player(self)
                except Exception:
                    LOG_CURRENT_EXCEPTION()

    result = _ORIG_ON_ENTER_WORLD(self, prereqs)

    if _BATTLE_ACTIVE and _PENDING_CTX is not None:
        props, at, compDescr, spaceID, ammoDict, hangarVehicle, vehInvID = _PENDING_CTX

        if getattr(self, 'spaceID', None) == spaceID:
            _PENDING_CTX = None
            _continueBattle(self, at, compDescr, spaceID, ammoDict, hangarVehicle=hangarVehicle, vehInvID=vehInvID)

    return result

def _onLeaveWorld(self, *args, **kwargs):
    global _BATTLE_ACTIVE

    # onLeaveWorld Avatar'а вызывается вручную из endbattle (пока Avatar ещё BigWorld.player()),
    # повторный вызов движком при destroyEntity пропускаем
    if getattr(self, '_offhangar_left', False):
        LOG_DEBUG('battle: Avatar.onLeaveWorld skipped (already done)')
        return
    try:
        self._offhangar_left = True
    except Exception:
        pass

    _resetCountdown()

    try:
        from gui.mods.offhangar import bots as off_bots
        off_bots.onBattleEnd()
    except Exception:
        LOG_CURRENT_EXCEPTION()

    try:
        AreaDestructibles.clear()
    except Exception:
        pass

    try:
        if getattr(self, 'terrainEffects', None) is not None:
            self.terrainEffects.destroy()
            self.terrainEffects = None
    except Exception:
        pass

    # _BATTLE_ACTIVE сбрасываем только ПОСЛЕ оригинального onLeaveWorld:
    # ему ещё нужен фейковый base/cell аватара (иначе AttributeError при выходе из боя).
    try:
        return _ORIG_ON_LEAVE_WORLD(self, *args, **kwargs)
    finally:
        _BATTLE_ACTIVE = False


# ============================================================
# Battle creation
# ============================================================
def _continueBattle(avatar, at, compDescr, spaceID, ammoDict, hangarVehicle=None, vehInvID=None):
    try:
        import AreaDestructibles

        if AreaDestructibles.g_destructiblesManager is None:
            AreaDestructibles.init()

        AreaDestructibles.g_destructiblesManager.startSpace(spaceID)

        LOG_DEBUG('AreaDestructibles space started: %s' % spaceID)

    except Exception:
        LOG_CURRENT_EXCEPTION()

    try:
        if getattr(avatar, 'terrainEffects', None) is None:
            from helpers import bound_effects

            avatar.terrainEffects = bound_effects.StaticSceneBoundEffects()

            LOG_DEBUG('terrainEffects created for offline battle')

    except Exception:
        LOG_CURRENT_EXCEPTION()

    try:
        pos = _spawnPos(at)

        vprops = {
            'publicInfo': _PublicInfo(compDescr, 1),
            'health': _getMaxHealth(compDescr),
            'isCrewActive': True,
            'engineMode': (0, 0),
            'publicStateModifiers': [],
            'damageStickers': [],
            'gunAnglesPacked': 0,
            'isStrafing': False,
        }

        LOG_DEBUG('battle: createEntity Vehicle at (%.1f,%.1f,%.1f) ...' % pos)

        vehicle = BigWorld.createEntity(
            'Vehicle',
            spaceID,
            0,
            pos,
            (0, 0, 0),
            vprops
        )

        if isinstance(vehicle, (int, long)):
            vehicle = BigWorld.entity(vehicle)

        if vehicle is not None:
            for k, v in vprops.items():
                try:
                    setattr(vehicle, k, v)
                except Exception:
                    pass

            LOG_DEBUG('battle: vehicle created synchronously id=%s' % getattr(vehicle, 'id', None))

            _finishVehicleSetup(avatar, vehicle, compDescr, ammoDict, hangarVehicle=hangarVehicle, vehInvID=vehInvID)
        else:
            LOG_DEBUG('battle: vehicle creation async, waiting for entity')
            BigWorld.callback(0.1, lambda: _waitForVehicleEntity(avatar, vprops, compDescr, spaceID, 50, ammoDict, hangarVehicle=hangarVehicle, vehInvID=vehInvID))
    except Exception:
        LOG_CURRENT_EXCEPTION()


def _waitForVehicleEntity(avatar, vprops, compDescr, spaceID, triesLeft, ammoDict, hangarVehicle=None, vehInvID=None):
    found = None

    try:
        import Vehicle as _V

        for e in BigWorld.entities.values():
            if (
                isinstance(e, _V.Vehicle)
                and getattr(e, 'spaceID', None) == spaceID
                and getattr(e, 'inWorld', False)
            ):
                found = e
                break

    except Exception:
        LOG_CURRENT_EXCEPTION()

    if found is None:
        if triesLeft > 0:
            BigWorld.callback(
                0.1,
                lambda: _waitForVehicleEntity(avatar, vprops, compDescr, spaceID, triesLeft - 1, ammoDict, hangarVehicle=hangarVehicle, vehInvID=vehInvID)
            )
        else:
            LOG_ERROR('battle: vehicle wait timeout')

        return

    for k, v in vprops.items():
        try:
            setattr(found, k, v)
        except Exception:
            pass

    LOG_DEBUG(
        'battle: vehicle appeared async id=%s inWorld=%s' % (
            getattr(found, 'id', None),
            found.inWorld,
        )
    )

    _finishVehicleSetup(avatar, found, compDescr, ammoDict, hangarVehicle=hangarVehicle, vehInvID=vehInvID)


def _finishVehicleSetup(avatar, vehicle, compDescr, ammoDict, hangarVehicle=None, vehInvID=None):
    try:
        vid = getattr(vehicle, 'id', 0)

        if vid:
            try:
                avatar.playerVehicleID = vid
                LOG_DEBUG('battle: playerVehicleID set = %s' % vid)
            except Exception:
                LOG_CURRENT_EXCEPTION()

            try:
                vehicle.isPlayer = True
            except Exception:
                LOG_CURRENT_EXCEPTION()

            try:
                avatar.updateArena(
                    ARENA_UPDATE.VEHICLE_LIST,
                    cPickle.dumps([_vehInfoTuple(vid or 1, compDescr, 1)])
                )
            except Exception:
                LOG_CURRENT_EXCEPTION()

            try:
                _startPrebattleCountdown(avatar)
            except Exception:
                LOG_CURRENT_EXCEPTION()

            try:
                from gui.mods.offhangar import bots as off_bots
                off_bots.onBattleStart(avatar)
            except Exception:
                LOG_CURRENT_EXCEPTION()

            BigWorld.callback(0.3, lambda: _finalize(avatar, 10))

            try:
                # Build prereqs mapping (model name -> BigWorld.Model) so Vehicle.appearance.start
                # can access loaded segment models (spline tracks) in offline mode.
                try:
                    names = []
                    try:
                        names = vehicle.prerequisites() or []
                    except Exception:
                        LOG_CURRENT_EXCEPTION()

                    prereqs_map = {}
                    for nm in set(names):
                        try:
                            if not nm:
                                continue
                            # attempt to load model; skip non-model resource names
                            if isinstance(nm, basestring) or isinstance(nm, str):
                                if nm.endswith('.model') or '/' in nm:
                                    m = BigWorld.Model(nm)
                                    prereqs_map[nm] = m
                        except Exception:
                            LOG_CURRENT_EXCEPTION()

                    try:
                        vehicle._Vehicle__prereqs = prereqs_map
                    except Exception:
                        LOG_CURRENT_EXCEPTION()
                except Exception:
                    LOG_CURRENT_EXCEPTION()

                avatar.vehicle_onEnterWorld(vehicle)
            except Exception:
                LOG_CURRENT_EXCEPTION()

            _startTurretRotation(avatar, vehicle)

            try:
                from gui.mods.offhangar import shooting as off_shooting
                if hangarVehicle is None and vehInvID is not None:
                    try:
                        hangarVehicle = off_shooting._resolveHangarVehicle(hangarVehicle=None, vehInvID=vehInvID)
                        if hangarVehicle is not None:
                            LOG_DEBUG('battle: resolved hangarVehicle from vehInvID=%s for consumables sync', vehInvID)
                    except Exception:
                        LOG_CURRENT_EXCEPTION()
                off_shooting.initAmmoForVehicle(vehicle, ammoDict)
                try:
                    _deferConsumablesSync(avatar, vehicle, hangarVehicle, vehInvID)
                    try:
                        BigWorld.callback(0.35, lambda: off_shooting.pushInitialAmmoUpdate(avatar, vehicle, hangarVehicle=hangarVehicle, vehInvID=vehInvID))
                    except Exception:
                        LOG_CURRENT_EXCEPTION()
                except Exception:
                    LOG_CURRENT_EXCEPTION()
            except Exception:
                LOG_CURRENT_EXCEPTION()

            try:
                _startVehicleEngineSound(vehicle)
            except Exception:
                LOG_CURRENT_EXCEPTION()

            try:
                avatar.updateArena(
                    ARENA_UPDATE.VEHICLE_LIST,
                    cPickle.dumps([_vehInfoTuple(vid or 1, compDescr, 1)])
                )
            except Exception:
                LOG_CURRENT_EXCEPTION()

            BigWorld.callback(0.3, lambda: _finalize(avatar, 10))

    except Exception:
        LOG_CURRENT_EXCEPTION()


def _finalize(avatar, tries):
    if avatar is None or not getattr(avatar, 'inWorld', False):
        if tries > 0:
            BigWorld.callback(0.2, lambda: _finalize(avatar, tries - 1))

        return

    if getattr(avatar, 'gunRotator', None) is None and tries > 0:
        BigWorld.callback(0.2, lambda: _finalize(avatar, tries - 1))
        return

    for _ in range(6):
        if avatar.userSeesWorld():
            break

        try:
            avatar.onSpaceLoaded()
        except Exception:
            LOG_CURRENT_EXCEPTION()

    LOG_DEBUG('battle: finalize userSeesWorld=%s' % avatar.userSeesWorld())

    try:
        avatar._PlayerAvatar__setIsOnArena(True)
        LOG_DEBUG('battle: forced isOnArena=True')
    except Exception:
        LOG_CURRENT_EXCEPTION()


def _battleGuiReady():
    try:
        from gui.WindowsManager import g_windowsManager
        w = g_windowsManager.battleWindow
        return w is not None and w.consumablesPanel is not None
    except Exception:
        return False


def _deferConsumablesSync(avatar, vehicle, hangarVehicle, vehInvID, tries=120):
    """Заливаем расходники в боевую панель, когда она создана."""
    if not _BATTLE_ACTIVE:
        return
    if _battleGuiReady():
        try:
            from gui.mods.offhangar import shooting as off_shooting
            off_shooting.syncHangarConsumablesToAvatar(avatar, vehicle, hangarVehicle=hangarVehicle, vehInvID=vehInvID)
            LOG_DEBUG('battle: consumables synced into battle GUI')
        except Exception:
            LOG_CURRENT_EXCEPTION()
        return
    if tries > 0:
        BigWorld.callback(0.25, lambda: _deferConsumablesSync(avatar, vehicle, hangarVehicle, vehInvID, tries - 1))
    else:
        LOG_DEBUG('battle: consumables panel never became ready')


def _startBattle(vehInvID):
    global _BATTLE_ACTIVE, _PENDING_CTX

    _BATTLE_ACTIVE = True
    _resetCountdown()

    try:
        from gui.mods.offhangar import endbattle as off_endbattle
        off_endbattle.onBattleStart(vehInvID)
    except Exception:
        LOG_CURRENT_EXCEPTION()

    try:
        from CurrentVehicle import g_currentVehicle

        compDescr = None
        ammoDict = None
        hangarVehicle = None

        try:
            if g_currentVehicle.isPresent():
                hangarVehicle = g_currentVehicle.item
                compDescr = hangarVehicle.descriptor.makeCompactDescr()
                ammoDict = dict(((s.intCD, s.count) for s in hangarVehicle.shells))
        except Exception:
            LOG_CURRENT_EXCEPTION()

        if hangarVehicle is None and vehInvID:
            try:
                from gui.shared import g_itemsCache
                hangarVehicle = g_itemsCache.items.getVehicle(vehInvID)
                if hangarVehicle is not None:
                    compDescr = hangarVehicle.descriptor.makeCompactDescr()
                    ammoDict = dict(((s.intCD, s.count) for s in hangarVehicle.shells))
            except Exception:
                LOG_CURRENT_EXCEPTION()

        if hangarVehicle is not None and vehInvID is None:
            try:
                vehInvID = getattr(hangarVehicle, 'invID', None)
                LOG_DEBUG('battle: resolved pending vehInvID=%s from hangarVehicle', vehInvID)
            except Exception:
                LOG_CURRENT_EXCEPTION()

        if compDescr is None:
            try:
                inv = BigWorld.player().inventory._Inventory__cache.get(
                    ITEM_TYPE_INDICES['vehicle'],
                    {}
                )

                cds = inv.get('compDescr', {})

                if cds:
                    compDescr = cds[sorted(cds.keys())[0]]

            except Exception:
                LOG_CURRENT_EXCEPTION()

        if compDescr is None:
            LOG_ERROR('battle: no compDescr, abort')

            _BATTLE_ACTIVE = False
            return

        at_id = _chooseArenaTypeID()

        if at_id is None:
            LOG_ERROR('battle: no arena type, abort')

            _BATTLE_ACTIVE = False
            return

        at = ArenaType.g_cache[at_id]

        LOG_DEBUG('battle: arena %s (%s)' % (at.geometryName, at_id))

        pos = _spawnPos(at)

        spaceID = BigWorld.createSpace()
        geom = getattr(at, 'geometry', None) or ('spaces/' + at.geometryName)

        try:
            import AreaDestructibles

            if AreaDestructibles.g_destructiblesManager is None:
                AreaDestructibles.init()
                LOG_DEBUG('AreaDestructibles.init() called before geometry load')

            AreaDestructibles.g_destructiblesManager.startSpace(spaceID)

            LOG_DEBUG('AreaDestructibles.startSpace(%s) called before geometry load' % spaceID)

        except Exception:
            LOG_CURRENT_EXCEPTION()

        BigWorld.addSpaceGeometryMapping(spaceID, None, geom)

        LOG_DEBUG('battle: space=%s geom=%s' % (spaceID, geom))

        props = {
            'arenaUniqueID': int(BigWorld.time() * 1000) & 0x7fffffff,
            'arenaTypeID': at.id,
            'arenaBonusType': ARENA_BONUS_TYPE.REGULAR,
            'arenaGuiType': ARENA_GUI_TYPE.RANDOM,
            'arenaExtraData': {},
            'weatherPresetID': 0,
            'team': 1,
            'playerVehicleID': 0,
            'name': OFFLINE_NICKNAME,
        }

        _PENDING_CTX = (props, at, compDescr, spaceID, ammoDict, hangarVehicle, vehInvID)

        avatar = BigWorld.createEntity(
            'Avatar',
            spaceID,
            0,
            pos,
            (0, 0, 0),
            props
        )

        if isinstance(avatar, (int, long)):
            avatar = BigWorld.entity(avatar)

        if avatar is not None:
            LOG_DEBUG('battle: avatar created synchronously')
        else:
            LOG_DEBUG('battle: avatar creation async, waiting for onEnterWorld')

    except Exception:
        LOG_CURRENT_EXCEPTION()

        _BATTLE_ACTIVE = False
        _PENDING_CTX = None


def _cmdEnqueueRandom(requestID, vehInvID, gameplaysMask, arenaTypeID):
    LOG_DEBUG('battle: CMD_ENQUEUE_RANDOM vehInvID=%s' % vehInvID)

    if not _isOffline():
        return (requestID, AccountCommands.RES_SUCCESS, '', None)

    try:
        p = BigWorld.player()

        p.onEnqueued(QUEUE_TYPE.RANDOMS)
        p.onArenaCreated()

    except Exception:
        LOG_CURRENT_EXCEPTION()

    BigWorld.callback(0.1, lambda: _startBattle(vehInvID))

    return (requestID, AccountCommands.RES_SUCCESS, '', None)



# ============================================================
# Registration
# ============================================================
def register():
    global _REGISTERED
    global _ORIG_INIT_STEP
    global _ORIG_ON_ENTER_WORLD
    global _ORIG_ON_LEAVE_WORLD

    if _REGISTERED:
        return

    _REGISTERED = True

    BASE_REQUESTS[AccountCommands.CMD_ENQUEUE_RANDOM] = _cmdEnqueueRandom

    _patchDestructibleDescLookup()

    import Avatar as _A

    cls = _A.PlayerAvatar

    _ORIG_INIT_STEP = getattr(cls, '_PlayerAvatar__onInitStepCompleted', None)
    cls._PlayerAvatar__onInitStepCompleted = _offlineInitStep

    _ORIG_ON_ENTER_WORLD = cls.onEnterWorld
    cls.onEnterWorld = _onEnterWorld

    _ORIG_ON_LEAVE_WORLD = cls.onLeaveWorld
    cls.onLeaveWorld = _onLeaveWorld

    _patchVehicleStartVisual()
    _patchEdgeDetect()
    _patchSplineTracks()
    _patchAvatarPositionControl()
    _patchAvatarBaseCell()
    _patchVehicleNativePhysics()
    _patchVehicleAppearanceHavok()
    _patchAvatarMoveVehicle()
    _patchAvatarOwnVehicleMatrix()
    _patchAvatarInputHandlerDetach() 

    _patchServerTime()
    _patchTrackKeys()

    try:
        from gui.mods.offhangar import endbattle as off_endbattle
        off_endbattle.register()
    except Exception:
        LOG_CURRENT_EXCEPTION()

    try:
        from gui.mods.offhangar import bots as off_bots
        off_bots.register()
    except Exception:
        LOG_CURRENT_EXCEPTION()

    LOG_NOTE('offline battle module registered')