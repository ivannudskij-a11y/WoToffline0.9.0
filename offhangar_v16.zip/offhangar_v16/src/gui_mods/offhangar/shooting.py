# -*- coding: utf-8 -*-
import BigWorld
import Math

from constants import VEHICLE_SETTING
try:
    from constants import EQUIPMENT_STAGES
except ImportError:
    class EQUIPMENT_STAGES(object):  # нет в 0.9.0
        READY = 1
from debug_utils import LOG_CURRENT_EXCEPTION
from gui.mods.offhangar.logging import LOG_DEBUG, LOG_NOTE, LOG_ERROR
from ModelHitTester import SegmentCollisionResult
from helpers.EffectMaterialCalculation import calcSurfaceMaterialNearPoint
import SoundGroups
_REGISTERED = False
_gunState = {}
_SHOT_ID_COUNTER = 0
_LAST_HANGAR_VEHICLE = None
_LAST_HANGAR_VEHICLE_INV_ID = None


def _nextShotID():
    global _SHOT_ID_COUNTER
    _SHOT_ID_COUNTER += 1
    return _SHOT_ID_COUNTER

def _active():
    from gui.mods.offhangar import battle as off_battle
    return off_battle._active()


def _initVehicleAmmo(vehicle):
    from items import vehicles as items_vehicles

    gunDescr = vehicle.typeDescriptor.gun
    ammo = items_vehicles.getUniformAmmoForGun(gunDescr)
    state = {'ammo': {}, 'reloadEnd': 0.0}
    it = iter(ammo)
    for cd, count in zip(it, it):
        state['ammo'][cd] = count
    _gunState[vehicle.id] = state
    return state


def initAmmoForVehicle(vehicle, ammoDict):
    gunDescr = vehicle.typeDescriptor.gun
    state = {'ammo': {}, 'reloadEnd': 0.0}
    if ammoDict:
        for cd, count in ammoDict.items():
            state['ammo'][cd] = count
    else:
        from items import vehicles as items_vehicles
        ammo = items_vehicles.getUniformAmmoForGun(gunDescr)
        it = iter(ammo)
        for cd, count in zip(it, it):
            state['ammo'][cd] = count
    _gunState[vehicle.id] = state
    return state


def _getItemCompactDescr(item):
    if item is None:
        return None

    try:
        if isinstance(item, (int, long)):
            return item
    except Exception:
        if isinstance(item, int):
            return item

    if isinstance(item, dict):
        return item.get('compactDescr') or item.get('intCD')

    for attr in ('intCD', 'compactDescr'):
        value = getattr(item, attr, None)
        if value:
            return value

    try:
        return item.compactDescr
    except Exception:
        return None


def _getHangarConsumables(hangarVehicle):
    result = []
    if hangarVehicle is None:
        return result

    try:
        eqs = getattr(hangarVehicle, 'eqs', None) or []
        for eq in eqs:
            intCD = _getItemCompactDescr(eq)
            if not intCD:
                continue
            quantity = getattr(eq, 'count', None)
            if quantity is None:
                quantity = getattr(eq, 'inventoryCount', None)
            if quantity is None:
                quantity = 1
            result.append((intCD, int(quantity), EQUIPMENT_STAGES.READY, 0))
    except Exception:
        LOG_CURRENT_EXCEPTION()

    return result


def _getHangarOptionalDevices(hangarVehicle):
    result = []
    if hangarVehicle is None:
        return result

    try:
        optDevices = getattr(hangarVehicle, 'optDevices', None) or []
        if optDevices:
            for device in optDevices:
                intCD = _getItemCompactDescr(device)
                if not intCD:
                    continue
                try:
                    from items import vehicles as items_vehicles
                    deviceID = items_vehicles.parseIntCompactDescr(intCD)[-1]
                except Exception:
                    deviceID = None
                if deviceID is None:
                    continue
                result.append((deviceID, True))
            return result
    except Exception:
        LOG_CURRENT_EXCEPTION()

    try:
        descriptor = getattr(hangarVehicle, 'descriptor', None)
        devices = getattr(descriptor, 'optionalDevices', None) or []
        for device in devices:
            intCD = _getItemCompactDescr(device)
            if not intCD:
                continue
            try:
                from items import vehicles as items_vehicles
                deviceID = items_vehicles.parseIntCompactDescr(intCD)[-1]
            except Exception:
                deviceID = None
            if deviceID is None:
                continue
            result.append((deviceID, True))
    except Exception:
        LOG_CURRENT_EXCEPTION()

    return result


def _resolveHangarVehicle(hangarVehicle=None, vehInvID=None):
    global _LAST_HANGAR_VEHICLE, _LAST_HANGAR_VEHICLE_INV_ID

    if hangarVehicle is not None:
        return hangarVehicle

    if vehInvID is not None:
        try:
            from gui.shared import g_itemsCache
            hangarVehicle = g_itemsCache.items.getVehicle(vehInvID)
            if hangarVehicle is not None:
                return hangarVehicle
        except Exception:
            LOG_CURRENT_EXCEPTION()

    if _LAST_HANGAR_VEHICLE is not None:
        LOG_DEBUG('[OFFHANGAR] _resolveHangarVehicle: using cached hangar vehicle invID=%s', getattr(_LAST_HANGAR_VEHICLE, 'invID', None))
        return _LAST_HANGAR_VEHICLE

    if _LAST_HANGAR_VEHICLE_INV_ID is not None:
        try:
            from gui.shared import g_itemsCache
            hangarVehicle = g_itemsCache.items.getVehicle(_LAST_HANGAR_VEHICLE_INV_ID)
            if hangarVehicle is not None:
                LOG_DEBUG('[OFFHANGAR] _resolveHangarVehicle: using cached hangar invID lookup %s', _LAST_HANGAR_VEHICLE_INV_ID)
                return hangarVehicle
        except Exception:
            LOG_CURRENT_EXCEPTION()

    g_currentVehicle = None
    try:
        from CurrentVehicle import g_currentVehicle
    except Exception:
        g_currentVehicle = None

    if g_currentVehicle is not None:
        try:
            hangarVehicle = getattr(g_currentVehicle, 'item', None)
            if hangarVehicle is not None:
                return hangarVehicle
        except Exception:
            LOG_CURRENT_EXCEPTION()

        try:
            from gui.shared import g_itemsCache
            currentInvID = getattr(g_currentVehicle, 'invID', None)
            if currentInvID:
                hangarVehicle = g_itemsCache.items.getVehicle(currentInvID)
                if hangarVehicle is not None:
                    return hangarVehicle
        except Exception:
            LOG_CURRENT_EXCEPTION()

    return None


def syncHangarConsumablesToAvatar(avatar, vehicle, hangarVehicle=None, vehInvID=None):
    global _LAST_HANGAR_VEHICLE, _LAST_HANGAR_VEHICLE_INV_ID

    if avatar is None or vehicle is None:
        return

    hangarVehicle = _resolveHangarVehicle(hangarVehicle=hangarVehicle, vehInvID=vehInvID)
    if hangarVehicle is not None:
        _LAST_HANGAR_VEHICLE = hangarVehicle
    if vehInvID is not None:
        _LAST_HANGAR_VEHICLE_INV_ID = vehInvID
    elif hangarVehicle is not None:
        _LAST_HANGAR_VEHICLE_INV_ID = getattr(hangarVehicle, 'invID', None)

    LOG_DEBUG('[OFFHANGAR] syncHangarConsumablesToAvatar: avatar=%s vehicle=%s hangarVehicle=%s vehInvID=%s', getattr(avatar, 'id', None), getattr(vehicle, 'id', None), getattr(hangarVehicle, 'invID', None) if hangarVehicle is not None else None, vehInvID)

    for intCD, quantity, stage, timeRemaining in _getHangarConsumables(hangarVehicle):
        try:
            LOG_DEBUG('[OFFHANGAR] syncHangarConsumablesToAvatar shell/equipment push: intCD=%s quantity=%s stage=%s timeRemaining=%s', intCD, quantity, stage, timeRemaining)
            avatar.updateVehicleAmmo(intCD, quantity, stage, timeRemaining)
        except Exception:
            LOG_CURRENT_EXCEPTION()

    for deviceID, isOn in _getHangarOptionalDevices(hangarVehicle):
        try:
            LOG_DEBUG('[OFFHANGAR] syncHangarConsumablesToAvatar optional device push: deviceID=%s isOn=%s', deviceID, isOn)
            avatar.updateVehicleOptionalDeviceStatus(deviceID, isOn)
        except Exception:
            LOG_CURRENT_EXCEPTION()

    return


_CONSUMABLES_PATCHED = False


def initAmmoForVehicle(vehicle, ammoDict):
    gunDescr = vehicle.typeDescriptor.gun
    state = {'ammo': {}, 'reloadEnd': 0.0}
    if ammoDict:
        for cd, count in ammoDict.items():
            state['ammo'][cd] = count
    else:
        from items import vehicles as items_vehicles
        ammo = items_vehicles.getUniformAmmoForGun(gunDescr)
        it = iter(ammo)
        for cd, count in zip(it, it):
            state['ammo'][cd] = count
    _gunState[vehicle.id] = state
    return state


def pushInitialAmmoUpdate(avatar, vehicle, hangarVehicle=None, vehInvID=None):
    st = _getState(vehicle)
    gunDescr = vehicle.typeDescriptor.gun

    try:
        LOG_DEBUG('[OFFHANGAR] pushInitialAmmoUpdate: avatar=%s vehicle=%s', getattr(avatar, 'id', None), getattr(vehicle, 'id', None))
        for cd, count in st['ammo'].items():
            LOG_DEBUG('[OFFHANGAR] pushInitialAmmoUpdate shells: cd=%s count=%s', cd, count)
            clipSize, _clipInterval = _clipParams(gunDescr)
            if clipSize > 1:
                st.setdefault('inClip', {})[cd] = min(clipSize, count)
                avatar.updateVehicleAmmo(cd, count, st['inClip'][cd], -1)
            else:
                avatar.updateVehicleAmmo(cd, count, count, -1)

        currentCD = _currentShellCD(vehicle)
        LOG_DEBUG('[OFFHANGAR] pushInitialAmmoUpdate current shell=%s', currentCD)
        avatar.updateVehicleSetting(VEHICLE_SETTING.CURRENT_SHELLS, currentCD)

        avatar.updateVehicleGunReloadTime(vehicle.id, 0.0, gunDescr['reloadTime'])
    except Exception:
        LOG_CURRENT_EXCEPTION()

    try:
        syncHangarConsumablesToAvatar(avatar, vehicle, hangarVehicle=hangarVehicle, vehInvID=vehInvID)
    except Exception:
        LOG_CURRENT_EXCEPTION()


def _patchConsumablesPanel():
    global _CONSUMABLES_PATCHED

    if _CONSUMABLES_PATCHED:
        return

    _CONSUMABLES_PATCHED = True

    try:
        from gui.Scaleform.daapi.view.battle.ConsumablesPanel import ConsumablesPanel

        _origStart = ConsumablesPanel.start

        def _safeStart(self, orig=_origStart):
            orig(self)

            if _active():
                def _doInitialUpdate():
                    try:
                        avatar = BigWorld.player()
                        if avatar is None:
                            LOG_DEBUG('[OFFHANGAR] ConsumablesPanel start: avatar not ready')
                            BigWorld.callback(0.1, _doInitialUpdate)
                            return
                        vehicle = BigWorld.entity(getattr(avatar, 'playerVehicleID', 0))
                        if vehicle is None:
                            LOG_DEBUG('[OFFHANGAR] ConsumablesPanel start: player vehicle not ready, retry')
                            BigWorld.callback(0.1, _doInitialUpdate)
                            return
                        LOG_DEBUG('[OFFHANGAR] ConsumablesPanel start: updating consumables for vehicle id=%s', vehicle.id)
                        pushInitialAmmoUpdate(avatar, vehicle, hangarVehicle=_LAST_HANGAR_VEHICLE, vehInvID=_LAST_HANGAR_VEHICLE_INV_ID)
                    except Exception:
                        LOG_CURRENT_EXCEPTION()

                try:
                    _doInitialUpdate()
                except Exception:
                    LOG_CURRENT_EXCEPTION()

        ConsumablesPanel.start = _safeStart
        LOG_NOTE('[OFFHANGAR] ConsumablesPanel start patch installed')

    except Exception:
        LOG_CURRENT_EXCEPTION()


def _getState(vehicle):
    st = _gunState.get(vehicle.id)
    if st is None:
        st = _initVehicleAmmo(vehicle)
    return st


def _currentShellCD(vehicle):
    gunDescr = vehicle.typeDescriptor.gun
    return gunDescr['shots'][vehicle.typeDescriptor.activeGunShotIndex]['shell']['compactDescr']


def _clipParams(gunDescr):
    """(размер магазина, интервал между выстрелами в магазине). Обычное орудие: (1, 0.0)."""
    try:
        clip = gunDescr['clip']
        return int(clip[0]), float(clip[1])
    except Exception:
        return 1, 0.0


def _clipQuantity(st, gunDescr, shellCD):
    """Сколько снарядов сейчас в магазине для данного типа снаряда."""
    clipSize, _ = _clipParams(gunDescr)
    inClip = st.setdefault('inClip', {})
    if shellCD not in inClip:
        inClip[shellCD] = min(clipSize, st['ammo'].get(shellCD, 0))
    return inClip[shellCD]


def _canShoot(vehicle):
    st = _getState(vehicle)
    if BigWorld.time() < st['reloadEnd']:
        return False
    return st['ammo'].get(_currentShellCD(vehicle), 0) > 0


def _shotOrigin(vehicle):
    turretYaw = Math.Matrix(vehicle.appearance.turretMatrix).yaw
    gunPitch = Math.Matrix(vehicle.appearance.gunMatrix).pitch
    vd = vehicle.typeDescriptor
    turretOffs = vd.hull['turretPositions'][0] + vd.chassis['hullPosition']

    turretMat = Math.Matrix()
    turretMat.setRotateY(turretYaw)
    turretMat.translation = turretOffs
    turretMat.postMultiply(vehicle.model.matrix)

    gunMat = Math.Matrix()
    gunMat.setRotateX(gunPitch)
    gunMat.postMultiply(turretMat)

    origin = gunMat.applyPoint(vd.turret['gunPosition'])
    direction = gunMat.applyVector(Math.Vector3(0, 0, 1))
    return (origin, direction)


_HIT_DIAG = {}


def _collideVehicle(e, start, end):
    """Аналог Vehicle.collideSegment без предварительной проверки по e.position:
    в офлайне модель двигает наша физика, а позиция сущности может отставать (у ботов - от точки спавна)."""
    try:
        res = e.collideSegment(start, end)
        if res is not None:
            return res
    except Exception:
        pass
    try:
        from ModelHitTester import SegmentCollisionResult
        m = Math.Matrix(e.model.matrix)
        m.invert()
        s = m.applyPoint(start)
        en = m.applyPoint(end)
        res = None
        for compDescr, compMatrix, isAttached in e.getComponents():
            if not isAttached:
                continue
            collisions = compDescr['hitTester'].localHitTest(compMatrix.applyPoint(s), compMatrix.applyPoint(en))
            if collisions is None:
                continue
            for dist, _, hitAngleCos, matKind in collisions:
                if res is None or res.dist >= dist:
                    matInfo = compDescr['materials'].get(matKind)
                    res = SegmentCollisionResult(dist, hitAngleCos, matInfo.armor if matInfo is not None else 0)
        return res
    except Exception:
        if not _HIT_DIAG.get('err'):
            _HIT_DIAG['err'] = True
            LOG_CURRENT_EXCEPTION()
        return None


def _findHitVehicle(shooter, start, end):
    best = None
    bestDist = None

    for e in BigWorld.entities.values():
        if e is shooter or not getattr(e, 'isStarted', False):
            continue
        if not hasattr(e, 'collideSegment') or getattr(e, 'model', None) is None:
            continue
        try:
            if e.health <= 0:
                continue
        except Exception:
            pass

        res = _collideVehicle(e, start, end)
        if res is None:
            continue

        if bestDist is None or res.dist < bestDist:
            bestDist = res.dist
            best = (e, res)

    return best


def _applyDamage(shooterID, target, shellDescr, hitAngleCos, armor, dist, maxDistance):
    # огонь по своим не наносит урона
    try:
        shooter = BigWorld.entity(shooterID)
        if shooter is not None and shooter.publicInfo['team'] == target.publicInfo['team']:
            return
    except Exception:
        pass

    # по уже уничтоженной машине урон не проходит (иначе повторный взрыв/килл)
    if target.health <= 0:
        return

    piercingPower = shellDescr.get('piercingPower', (0, 0))
    speedFactor = max(0.1, 1.0 - dist / max(1.0, maxDistance))
    pierce = piercingPower[0] * speedFactor

    if hitAngleCos:
        armor = armor / max(0.15, hitAngleCos)

    if pierce < armor:
        return

    damage = shellDescr['damage'][0]
    prevHealth = target.health
    newHealth = max(0, prevHealth - damage)

    target.health = newHealth
    try:
        target.set_health(prevHealth)
    except Exception:
        LOG_CURRENT_EXCEPTION()

    try:
        target.onHealthChanged(newHealth, shooterID, 0)
    except Exception:
        LOG_CURRENT_EXCEPTION()

    # здоровье собственной машины игрока показывает интерфейс (панель повреждений, прицел)
    try:
        av = BigWorld.player()
        if getattr(av, 'playerVehicleID', None) == target.id:
            av.updateVehicleHealth(newHealth, True)
    except Exception:
        LOG_CURRENT_EXCEPTION()

    if newHealth <= 0:
        try:
            from gui.mods.offhangar import bots as off_bots
            off_bots.onVehicleKilled(target, shooterID)
        except Exception:
            LOG_CURRENT_EXCEPTION()

def _tryDestructibleHit(vehicle, origin, end):
    try:
        res_dest = BigWorld.wg_collideSegment(vehicle.spaceID, origin, end, 128)
    except Exception:
        res_dest = None

    if res_dest is None or len(res_dest) <= 5:
        return None

    hitPoint = res_dest[0]
    dist = (hitPoint - origin).length

    from gui.mods.offhangar import battle as off_battle

    sp = off_battle._simplePhysicsByVehID.get(vehicle.id)
    if sp is not None:
        try:
            sp._tryDestroyDestructible(
                vehicle.spaceID,
                res_dest[5],
                res_dest[4],
                res_dest[2],
                Math.Matrix(vehicle.model.matrix).yaw,
                12.0
            )
        except Exception:
            LOG_CURRENT_EXCEPTION()

    return (dist, hitPoint)


def _findStaticHit(vehicle, origin, end):
    try:
        res = BigWorld.wg_collideSegment(vehicle.spaceID, origin, end, 0)
    except Exception:
        res = None

    if res is None:
        return None

    hitPoint = res[0]
    if hitPoint is None:
        return None

    normal = None
    if len(res) > 1:
        try:
            n = res[1]
            normal = Math.Vector3(float(n[0]), float(n[1]), float(n[2]))
        except Exception:
            normal = None

    dist = (hitPoint - origin).length
    return (dist, hitPoint, normal)

def _resolveShot(avatar, vehicle):
    st = _getState(vehicle)
    shellCD = _currentShellCD(vehicle)
    gunDescr = vehicle.typeDescriptor.gun
    shot = gunDescr['shots'][vehicle.typeDescriptor.activeGunShotIndex]
    shellDescr = shot['shell']
    maxDistance = shot['maxDistance']
    shellSpeed = shot['speed']
    shellGravity = shot['gravity']

    origin, direction = _shotOrigin(vehicle)
    end = origin + direction * maxDistance

    hit = _findHitVehicle(vehicle, origin, end)

    hitDist = maxDistance
    endPoint = end
    hitKind = 'none'
    hitNormal = None

    if hit is not None:
        target, res = hit
        hitDist = res.dist
        endPoint = origin + direction * hitDist
        hitKind = 'vehicle'

        _applyDamage(vehicle.id, target, shellDescr, res.hitAngleCos, res.armor, res.dist, maxDistance)
        try:
            target.showDamageFromShot(vehicle.id, [], shellDescr['effectsIndex'])
        except Exception:
            LOG_CURRENT_EXCEPTION()
    else:
        destRes = _tryDestructibleHit(vehicle, origin, end)
        staticRes = _findStaticHit(vehicle, origin, end)

        candidates = []
        if destRes is not None:
            candidates.append(('destructible', destRes[0], destRes[1], None))
        if staticRes is not None:
            candidates.append(('static', staticRes[0], staticRes[1], staticRes[2]))

        if candidates:
            candidates.sort(key=lambda c: c[1])
            hitKind, hitDist, endPoint, hitNormal = candidates[0]

    shotID = _nextShotID()

    try:
        # play visual/sound effects for shot (muzzle flash, recoil, sound)
        try:
            from items import vehicles as items_vehicles
            effectsDescr = items_vehicles.g_cache.shotEffects[shellDescr['effectsIndex']]
            try:
                # start vehicle shooting extra (muzzle flash, recoil)
                vehicle.showShooting(gunDescr['burst'][0], True)
            except Exception:
                LOG_CURRENT_EXCEPTION()
            # try common keys for sound events
            soundEvent = None
            for key in ('shotSound', 'sound', 'soundEvent'):
                if key in effectsDescr:
                    soundEvent = effectsDescr[key]
                    break
            if soundEvent:
                try:
                    SoundGroups.g_instance.playSound(vehicle.appearance.modelsDesc['gun']['model'], soundEvent)
                except Exception:
                    LOG_CURRENT_EXCEPTION()
        except Exception:
            LOG_CURRENT_EXCEPTION()

        velocity = direction * shellSpeed
        avatar.showTracer(
            vehicle.id,
            shotID,
            shellDescr['effectsIndex'],
            origin,
            velocity,
            shellGravity,
            maxDistance
        )

        flightTime = max(0.01, hitDist / max(1.0, shellSpeed))

        def _finishShot(sid=shotID, ep=endPoint, kind=hitKind, normal=hitNormal, dirv=direction, effIdx=shellDescr['effectsIndex']):
            try:
                av = BigWorld.player()
                if av is None:
                    return

                if kind == 'static':
                    try:
                        n = normal if normal is not None else Math.Vector3(0.0, 1.0, 0.0)
                        surfaceMaterial = calcSurfaceMaterialNearPoint(ep, n, av.spaceID)
                        hitPoint2, surfNormal, matKind, materialEffIdx = surfaceMaterial
                        av.explodeProjectile(sid, effIdx, materialEffIdx, hitPoint2, dirv, None)
                    except Exception:
                        LOG_CURRENT_EXCEPTION()
                        av.stopTracer(sid, ep)
                else:
                    av.stopTracer(sid, ep)
            except Exception:
                LOG_CURRENT_EXCEPTION()

        BigWorld.callback(flightTime, _finishShot)
    except Exception:
        LOG_CURRENT_EXCEPTION()

    clipSize, clipInterval = _clipParams(gunDescr)
    inClipBefore = _clipQuantity(st, gunDescr, shellCD)
    st['ammo'][shellCD] = max(0, st['ammo'].get(shellCD, 0) - 1)

    # Барабан / магазин: между выстрелами в магазине - короткий интервал,
    # полная перезарядка только когда магазин опустел (или снарядов больше нет).
    quantityInClip = None
    if clipSize > 1:
        inClipNow = inClipBefore - 1
        if inClipNow > 0 and st['ammo'][shellCD] > 0:
            st['inClip'][shellCD] = inClipNow
            reloadTime = clipInterval if clipInterval > 0.0 else 0.1
        else:
            st['inClip'][shellCD] = min(clipSize, st['ammo'][shellCD])
            reloadTime = gunDescr['reloadTime']
        quantityInClip = st['inClip'][shellCD]
    else:
        reloadTime = gunDescr['reloadTime']

    st['reloadEnd'] = BigWorld.time() + reloadTime

    try:
        left = st['ammo'][shellCD]
        avatar.updateVehicleAmmo(shellCD, left, left if quantityInClip is None else quantityInClip, -1)
        avatar.updateVehicleGunReloadTime(vehicle.id, reloadTime, reloadTime)

        vehID = vehicle.id

        def _notifyReloaded(vid=vehID, rt=reloadTime):
            try:
                av = BigWorld.player()
                veh = BigWorld.entity(vid)
                if av is None or veh is None:
                    return
                st2 = _gunState.get(vid)
                if st2 is None:
                    return
                if BigWorld.time() < st2['reloadEnd'] - 0.01:
                    return
                av.updateVehicleGunReloadTime(vid, 0.0, rt)
            except Exception:
                LOG_CURRENT_EXCEPTION()

        BigWorld.callback(reloadTime, _notifyReloaded)
    except Exception:
        LOG_CURRENT_EXCEPTION()

    # effects already triggered above


def _patchAvatarShoot():
    try:
        import Avatar as _A

        cls = _A.PlayerAvatar
        orig = cls.shoot

        def patched(self, isRepeat=False, orig=orig):
            if not _active():
                return orig(self, isRepeat)

            # во время обратного отсчёта стрелять нельзя
            from gui.mods.offhangar import battle as off_battle
            if off_battle.isPrebattle():
                return

            vehicle = BigWorld.entity(self.playerVehicleID)
            if vehicle is None or not vehicle.isStarted:
                return

            if not _canShoot(vehicle):
                return

            _resolveShot(self, vehicle)

        cls.shoot = patched
        LOG_NOTE('[OFFHANGAR] offline shooting patch installed')
    except Exception:
        LOG_ERROR('[OFFHANGAR] offline shooting patch FAILED')
        LOG_CURRENT_EXCEPTION()

def register():
    global _REGISTERED

    if _REGISTERED:
        return

    _REGISTERED = True
    _patchAvatarShoot()
    _patchConsumablesPanel()
    LOG_NOTE('offline shooting module registered') 