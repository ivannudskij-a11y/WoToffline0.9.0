# -- coding: utf-8 --
import time
import cPickle
from chat_shared import CHAT_RESPONSES


OFFLINE_SERVER_ADDRESS = 'offline.loc'
OFFLINE_NICKNAME = 'Player'
OFFLINE_LOGIN = OFFLINE_NICKNAME + '@' + OFFLINE_SERVER_ADDRESS
OFFLINE_PWD = '1'
OFFLINE_DBID = 1000001


OFFLINE_GUI_CTX = cPickle.dumps({
    'databaseID': OFFLINE_DBID,
    'name': OFFLINE_NICKNAME,
    'logUXEvents': False,

    # Anti-online-game-addiction / playtime related
    'aogasStartedAt': 0,
    'sessionStartedAt': int(time.time()),
    'isAogasEnabled': False,

    'collectUiStats': False,
    'isLongDisconnectedFromCenter': False,

    # Extra safety, if client reads this from ctx
    'playLimits': ((0, ''), (0, '')),
    'dailyPlayHours': [0, 0, 0, 0, 0, 0, 0],
}, cPickle.HIGHEST_PROTOCOL)


OFFLINE_QUESTS_PROGRESS = {
    'quests': {},
    'tokens': {},
    'potapovQuests': {
        'compDescr': '',
        'slots': 3,
        'selected': set(),
        'rewards': {},
        'lastIDs': {}
    },
    'history': {},
    'sortie': {},
    'fort_battles': {}
}


OFFLINE_SERVER_SETTINGS = {
    'file_server': {},

    'roaming': ([], [], [], []),
    'isPotapovQuestEnabled': True,

    'regional_settings': {
        # Оставляем оба варианта написания, потому что в коде есть weak/week
        'starting_day_of_a_new_week': 0,
        'starting_day_of_a_new_weak': 0,

        'starting_time_of_a_new_game_day': 0,
        'starting_time_of_a_new_day': 0,
    },

    'xmpp_enabled': False,
    'xmpp_port': 0,
    'xmpp_host': '',
    'xmpp_muc_enabled': False,
    'xmpp_muc_services': [],
    'xmpp_resource': '',
    'xmpp_bosh_connections': [],
    'xmpp_connections': [],
    'xmpp_alt_connections': [],

    'voipDomain': '',
    'voipUserDomain': '',

    'wallet': (1, 1),
    'isTutorialEnabled': False,
    'newbieBattlesCount': 0,
    'reCaptchaParser': '',

    # Дополнительные ключи против лимитов
    'aogas_enabled': False,
    'isAogasEnabled': False,
    'playtime_limit': 0,
    'playLimits': ((0, ''), (0, '')),
    'dailyPlayHours': [0, 0, 0, 0, 0, 0, 0],
}


CHAT_ACTION_DATA = {
    'requestID': None,
    'action': None,
    'actionResponse': CHAT_RESPONSES.internalError.index(),
    'time': 0,
    'sentTime': 0,
    'channel': 0,
    'originator': 0,
    'originatorNickName': '',
    'group': 0,
    'data': {},
    'flags': 0
}

OFFLINE_BATTLE_MAP_POOL = [
    # '01_karelia',
    # '02_malinovka',
]

OFFLINE_BATTLE_DEFAULT_GAMEPLAY = 'ctf'

OFFLINE_BATTLE_PERIOD_LENGTH = 900

REQUEST_CALLBACK_TIME = 0.5