\xef\xbb\xbfOFFLINE HANGAR for WoT 0.9.0 - v16 (боты: исправление вылета после отсчёта)

Установка: install.bat (нужен Python 2.7) -> перетащить в окно папку игры -> Enter.
Изменился только bots.py, но компилируются все четыре модуля (bots, battle, shooting, endbattle).

Вылет сразу после окончания обратного отсчёта
  В логе после "PREBATTLE finished -> BATTLE started" не было ни одной ошибки Python - падал нативный код.
  Единственное новое нативное действие в этот момент - вызов vehicle.filter.syncGunAngles(...) у ботов
  (башни начинают наводиться). Нативная физика в офлайне отключена, и фильтр машины к такому вызову не готов.
  Теперь башня бота работает так же, как башня игрока: свои матрицы (_RotAnimator) подставляются
  в appearance.turretMatrix / appearance.gunMatrix. syncGunAngles больше не вызывается.

Если игра всё равно падает
  В начале bots.py есть три выключателя (поставь True, пересобери install.bat и проверь):
      BOT_DEBUG_NO_TURRET  - башни ботов не вращаются
      BOT_DEBUG_NO_MOVE    - боты не ездят
      BOT_DEBUG_NO_FIRE    - боты не стреляют
  Выключай по одному: тот, после которого вылет пропал, и есть виновник. Пришли мне, что получилось
  и последние ~30 строк offhangar_debug.log.

Новые строки в логе (по ним видно, докуда дошёл бот перед вылетом):
   [BOTS] turret matrices attached for vehicle N
   [BOTS] bot N first think: target=... dist=... follow=...
   [BOTS] turret first update, vehicle N

v16: попадания по машинам (в т.ч. по ботам и по игроку) считаются без проверки по устаревшей позиции
сущности; боты получают targetCaps и сбрасывается stipple (полупрозрачность). В лог пишутся строки
[BOTS] bot N diag / state / aimed but ray hits ... - пришли offhangar_debug.log, если что-то не так.
